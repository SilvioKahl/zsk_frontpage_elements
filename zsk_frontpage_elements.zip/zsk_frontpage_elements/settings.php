<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (settings.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

use local_zsk_frontpage_elements\admin\admin_nav;

require_once(__DIR__ . '/lib.php');

if ($hassiteconfig) {
    admin_nav::ensure_category($ADMIN);

    $settings = new admin_settingpage(
        'local_zsk_frontpage_elements',
        get_string('settings', 'local_zsk_frontpage_elements')
    );

    $settings->add(new admin_setting_heading(
        'local_zsk_frontpage_elements/settings_heading',
        get_string('settings', 'local_zsk_frontpage_elements'),
        get_string('settings_intro', 'local_zsk_frontpage_elements')
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_zsk_frontpage_elements/enabled',
        get_string('settings_enabled', 'local_zsk_frontpage_elements'),
        get_string('settings_enabled_desc', 'local_zsk_frontpage_elements'),
        1
    ));

    $settings->add(new admin_setting_description(
        'local_zsk_frontpage_elements/manage_hint',
        get_string('manage_elements', 'local_zsk_frontpage_elements'),
        html_writer::link(
            new moodle_url('/local/zsk_frontpage_elements/manage.php'),
            get_string('manage_elements', 'local_zsk_frontpage_elements')
        ) . '<br><br>' .
        html_writer::link(
            new moodle_url('/admin/settings.php', ['section' => 'frontpagesettings']),
            get_string('frontpage_settings_link', 'local_zsk_frontpage_elements')
        )
    ));

    admin_nav::add_page($ADMIN, $settings);

    $managepage = new admin_externalpage(
        'local_zsk_frontpage_elements_manage',
        get_string('manage_elements', 'local_zsk_frontpage_elements'),
        new moodle_url('/local/zsk_frontpage_elements/manage.php'),
        'local/zsk_frontpage_elements:manage'
    );
    admin_nav::add_page($ADMIN, $managepage);

    require_once(__DIR__ . '/classes/admin/frontpage_settings.php');
    \local_zsk_frontpage_elements\admin\frontpage_settings::patch_admin_tree();
}
