# Changelog

All notable changes to `local_zsk_frontpage_elements` are documented here.

## 1.5.1 – 2026-07-31

- Removed remaining cross-plugin API usage (tiles/termine picker injection)
- Documented recommended Git repo name `moodle-local_zsk_frontpage_elements`
- No `$plugin->dependencies` needed (plugin is standalone)

## 1.5.0 – 2026-07-31

Moodle.org review compliance pass:

- Added `LICENSE`, GitHub Actions workflow, Mustache templates + plugin renderer
- Capability language string `zsk_frontpage_elements:manage`
- `require_login` on `view.php`; removed insecure `recover_config.php` and SQL recovery helper
- No direct `config_plugins` table access; seed defaults scoped to this plugin only
- File `@copyright` / `@license` headers; CLI messages via language strings

## 1.4.4 – 2025-06-03

- moodle.org submission: root `README.md` and release notes
- Stable maturity; version `2025060324`
- Config defaults seeded on upgrade (`local_zsk_frontpage_elements_seed_config_defaults`)
- Administrator and product documentation in `docs/de/` and `docs/en/`

## 1.4.3 – 2025-06-03

- Front page rendering and hook callbacks refined
- `recover_config.php` and SQL helper for missing `config_plugins` rows (redirect loop fix)

## 1.4.2 – 2025-06-03

- File-link elements: choose **upload** or **external URL** (`filesource`, `externallink`)
- Validation in element form for external links

## 1.4.1 – 2025-06-03

- Selectable **link icons** for link and file elements (page, file, book, info, calendar, and more)
- Database field `linkicon`

## 1.4.0 – 2025-06-03

- **Display modes** per element: inline on site home, link to separate page, direct file link
- Database field `displaymode`
- Dedicated view page for link-mode content (`view.php`)

## 1.3.x – 2025-06

- Plugin `local_zsk_frontpage_elements` (successor to legacy front page custom content approaches)
- Management UI: list, create, edit, delete elements
- Elements registered in Moodle front page settings (`frontpage` / `frontpageloggedin`)
- Capability `local/zsk_frontpage_elements:manage`
- Privacy provider
- Optional integration with `local_zsk_local_tiles` and `local_zsk_termine` in the same front page picker
- CLI `cli/seed_defaults.php`
- German and English language packs
