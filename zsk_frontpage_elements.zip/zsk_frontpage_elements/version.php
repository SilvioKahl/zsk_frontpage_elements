<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for local_zsk_frontpage_elements.
 *
 * Plugin directory on disk: zsk_frontpage_elements
 * Frankenstyle component: local_zsk_frontpage_elements
 * Recommended public Git repository name: moodle-local_zsk_frontpage_elements
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_zsk_frontpage_elements';
$plugin->version   = 2025073101;
$plugin->requires  = 2022112800; // Moodle 4.1.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.5.1';
