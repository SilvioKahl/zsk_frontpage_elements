<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lang/it/local_zsk_frontpage_elements.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Elementi della prima pagina personalizzati ZSK';
$string['zsk_frontpage_elements:manage'] = 'Manage ZSK custom front page elements';
$string['admin_category'] = 'Elementi della prima pagina personalizzati ZSK';
$string['settings'] = 'Impostazioni';
$string['settings_intro'] = 'Crea sezioni di contenuto personalizzate per la home del sito e inseriscile liberamente nelle impostazioni della prima pagina di Moodle.';
$string['settings_enabled'] = 'Abilita plug-in';
$string['settings_enabled_desc'] = 'Se disabilitati, gli elementi personalizzati della prima pagina non vengono visualizzati o offerti nelle impostazioni della prima pagina.';
$string['manage_elements'] = 'Gestisci gli elementi della prima pagina';
$string['manage_intro'] = 'Crea sezioni di testo e multimediali qui. Utilizza "Come collegamento" per le pagine di testo e "Come collegamento a file" per PDF e documenti. Quindi posizionali liberamente in Amministrazione del sito → Pagina iniziale → Impostazioni pagina iniziale.';
$string['frontpage_settings_link'] = 'Apri le impostazioni della prima pagina';
$string['add_element'] = 'Aggiungi elemento';
$string['edit_element'] = 'Modifica elemento';
$string['element_name'] = 'Titolo';
$string['element_content'] = 'Contenuto';
$string['element_displaymode'] = 'Visualizzazione sulla home del sito';
$string['element_displaymode_help'] = '"Direttamente sulla home page del sito" mostra il titolo e il contenuto nel blocco. "Come collegamento (pagina separata)" mostra solo un titolo cliccabile; il contenuto appare sulla propria pagina. "Come collegamento al file" apre direttamente un file, caricato in Moodle o tramite un URL esterno (ad esempio PDF).';
$string['displaymode_inline'] = 'Direttamente sul posto a casa';
$string['displaymode_link'] = 'Come collegamento (pagina separata)';
$string['displaymode_file'] = 'Come collegamento al file (ad es. PDF)';
$string['element_filesource'] = 'Origine del file';
$string['element_filesource_help'] = 'Scegli se caricare un file in Moodle o collegarlo ad un indirizzo esterno.';
$string['filesource_upload'] = 'Carica file';
$string['filesource_external'] = 'URL esterno';
$string['element_externallink'] = 'URL esterno';
$string['element_externallink_help'] = 'Indirizzo completo del file (http:// o https://), ad es. un PDF ospitato altrove.';
$string['element_attachment'] = 'File';
$string['element_attachment_help'] = 'Carica un file (ad esempio PDF). Facendo clic sul titolo nella home del sito si apre direttamente il file.';
$string['element_linkicon'] = 'Icona di collegamento';
$string['element_linkicon_help'] = 'Icona mostrata accanto al collegamento del titolo nella home del sito. Per i collegamenti ai file, si consiglia "File".';
$string['linkicon_page'] = 'Pagina (come pagina di testo)';
$string['linkicon_file'] = 'File (come l\'attività sui file)';
$string['linkicon_book'] = 'Libro';
$string['linkicon_info'] = 'Informazioni';
$string['linkicon_news'] = 'Notizia';
$string['linkicon_help'] = 'Aiuto';
$string['linkicon_globe'] = 'Rete/globo';
$string['linkicon_group'] = 'Gruppo/squadra';
$string['linkicon_calendar'] = 'Calendario/evento';
$string['linkicon_comment'] = 'Dialogo/commento';
$string['element_slot'] = 'ID dello slot';
$string['view_element'] = 'Contenuto della prima pagina';
$string['back_to_frontpage'] = 'Torna alla home page del sito';
$string['disabled'] = 'Gli elementi della prima pagina sono disabilitati.';
$string['frontpage_element_choice'] = 'ZSK: {$a}';
$string['no_elements'] = 'Nessun elemento della prima pagina ancora creato.';
$string['element_created'] = 'Elemento della prima pagina creato.';
$string['element_updated'] = 'Elemento della prima pagina salvato.';
$string['element_deleted'] = 'Elemento della prima pagina eliminato.';
$string['invalidelement'] = 'Elemento della prima pagina non trovato.';
$string['privacy:metadata'] = 'Il plugin memorizza il contenuto della prima pagina creato dagli amministratori. Nessun dato personale dei visitatori viene memorizzato.';

// Auto-synced missing keys from en.

$string['cli_seed_heading'] = 'Seed config defaults (local_zsk_frontpage_elements)';
$string['cli_seed_static_count'] = '{$a} static defaults written.';
$string['cli_seed_static_none'] = 'No missing static defaults.';
$string['cli_seed_admin_count'] = '{$a} admin defaults initialised.';
$string['cli_seed_warnings'] = 'Warnings:';
$string['cli_seed_no_pending'] = 'No open upgradesettings for this plugin.';
$string['cli_seed_still_pending'] = 'Still pending:';
$string['cli_seed_next_steps'] = 'Next steps:';
$string['cli_seed_step_cookies'] = 'Clear browser cookies for this site';
$string['cli_seed_step_reload'] = 'Open /admin or the site home again (do not bookmark upgradesettings.php)';
