<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lang/en/local_zsk_frontpage_elements.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'ZSK custom front page elements';
$string['zsk_frontpage_elements:manage'] = 'Manage ZSK custom front page elements';
$string['admin_category'] = 'ZSK custom front page elements';
$string['settings'] = 'Settings';
$string['settings_intro'] = 'Create custom content sections for the site home and place them freely in Moodle front page settings.';
$string['settings_enabled'] = 'Enable plugin';
$string['settings_enabled_desc'] = 'When disabled, custom front page elements are not shown or offered in front page settings.';
$string['manage_elements'] = 'Manage front page elements';
$string['manage_intro'] = 'Create text and media sections here. Use “As link” for text pages and “As file link” for PDFs and documents. Then place them freely under Site administration → Front page → Front page settings.';
$string['frontpage_settings_link'] = 'Open front page settings';
$string['add_element'] = 'Add element';
$string['edit_element'] = 'Edit element';
$string['element_name'] = 'Title';
$string['element_content'] = 'Content';
$string['element_displaymode'] = 'Display on site home';
$string['element_displaymode_help'] = '“Directly on site home” shows the title and content in the block. “As link (separate page)” shows only a clickable title; the content appears on its own page. “As file link” opens a file directly – either uploaded in Moodle or via an external URL (e.g. PDF).';
$string['displaymode_inline'] = 'Directly on site home';
$string['displaymode_link'] = 'As link (separate page)';
$string['displaymode_file'] = 'As file link (e.g. PDF)';
$string['element_filesource'] = 'File source';
$string['element_filesource_help'] = 'Choose whether to upload a file in Moodle or link to an external address.';
$string['filesource_upload'] = 'Upload file';
$string['filesource_external'] = 'External URL';
$string['element_externallink'] = 'External URL';
$string['element_externallink_help'] = 'Full address to the file (http:// or https://), e.g. a PDF hosted elsewhere.';
$string['element_attachment'] = 'File';
$string['element_attachment_help'] = 'Upload one file (e.g. PDF). Clicking the title on the site home opens the file directly.';
$string['element_linkicon'] = 'Link icon';
$string['element_linkicon_help'] = 'Icon shown next to the title link on the site home. For file links, “File” is recommended.';
$string['linkicon_page'] = 'Page (like text page)';
$string['linkicon_file'] = 'File (like file activity)';
$string['linkicon_book'] = 'Book';
$string['linkicon_info'] = 'Information';
$string['linkicon_news'] = 'News';
$string['linkicon_help'] = 'Help';
$string['linkicon_globe'] = 'Web / globe';
$string['linkicon_group'] = 'Group / team';
$string['linkicon_calendar'] = 'Calendar / event';
$string['linkicon_comment'] = 'Dialogue / comment';
$string['element_slot'] = 'Slot ID';
$string['view_element'] = 'Front page content';
$string['back_to_frontpage'] = 'Back to site home';
$string['disabled'] = 'Front page elements are disabled.';
$string['frontpage_element_choice'] = 'ZSK: {$a}';
$string['no_elements'] = 'No front page elements created yet.';
$string['element_created'] = 'Front page element created.';
$string['element_updated'] = 'Front page element saved.';
$string['element_deleted'] = 'Front page element deleted.';
$string['invalidelement'] = 'Front page element not found.';
$string['privacy:metadata'] = 'The plugin stores front page content created by administrators. No personal visitor data is stored.';

$string['cli_seed_heading'] = 'Seed config defaults (local_zsk_frontpage_elements)';
$string['cli_seed_static_count'] = '{$a} static defaults written.';
$string['cli_seed_static_none'] = 'No missing static defaults.';
$string['cli_seed_admin_count'] = '{$a} admin defaults initialised.';
$string['cli_seed_warnings'] = 'Warnings:';
$string['cli_seed_no_pending'] = 'No open upgradesettings for this plugin.';
$string['cli_seed_still_pending'] = 'Still pending:';
$string['cli_seed_next_steps'] = 'Next steps:';
$string['cli_seed_step_cookies'] = 'Clear browser cookies for this site';
$string['cli_seed_step_reload'] = 'Open /admin or the site home again (do not bookmark upgradesettings.php)';
