<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lang/es/local_zsk_frontpage_elements.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Elementos de portada personalizados de ZSK';
$string['zsk_frontpage_elements:manage'] = 'Manage ZSK custom front page elements';
$string['admin_category'] = 'Elementos de portada personalizados de ZSK';
$string['settings'] = 'Ajustes';
$string['settings_intro'] = 'Cree secciones de contenido personalizadas para el inicio del sitio y colóquelas libremente en la configuración de la página principal de Moodle.';
$string['settings_enabled'] = 'Habilitar complemento';
$string['settings_enabled_desc'] = 'Cuando está deshabilitado, los elementos personalizados de la página principal no se muestran ni se ofrecen en la configuración de la página principal.';
$string['manage_elements'] = 'Administrar elementos de la página principal';
$string['manage_intro'] = 'Cree secciones de texto y medios aquí. Utilice "Como enlace" para páginas de texto y "Como enlace de archivo" para archivos PDF y documentos. Luego colóquelos libremente en Administración del sitio → Página principal → Configuración de la página principal.';
$string['frontpage_settings_link'] = 'Abrir la configuración de la página principal';
$string['add_element'] = 'Agregar elemento';
$string['edit_element'] = 'Editar elemento';
$string['element_name'] = 'Título';
$string['element_content'] = 'Contenido';
$string['element_displaymode'] = 'Mostrar en el sitio de inicio';
$string['element_displaymode_help'] = '“Inicio directamente en el sitio” muestra el título y el contenido del bloque. “Como enlace (página separada)” muestra solo un título en el que se puede hacer clic; el contenido aparece en su propia página. "Como enlace de archivo" abre un archivo directamente, ya sea cargado en Moodle o mediante una URL externa (por ejemplo, PDF).';
$string['displaymode_inline'] = 'Directamente en el sitio de inicio';
$string['displaymode_link'] = 'Como enlace (página separada)';
$string['displaymode_file'] = 'Como enlace de archivo (por ejemplo, PDF)';
$string['element_filesource'] = 'Fuente del archivo';
$string['element_filesource_help'] = 'Elija si desea cargar un archivo en Moodle o vincularlo a una dirección externa.';
$string['filesource_upload'] = 'Subir archivo';
$string['filesource_external'] = 'URL externa';
$string['element_externallink'] = 'URL externa';
$string['element_externallink_help'] = 'Dirección completa del archivo (http:// o https://), p.e. un PDF alojado en otro lugar.';
$string['element_attachment'] = 'Archivo';
$string['element_attachment_help'] = 'Cargue un archivo (por ejemplo, PDF). Al hacer clic en el título en la página de inicio del sitio, se abre el archivo directamente.';
$string['element_linkicon'] = 'icono de enlace';
$string['element_linkicon_help'] = 'Icono que se muestra junto al enlace del título en la página de inicio del sitio. Para enlaces de archivos, se recomienda "Archivo".';
$string['linkicon_page'] = 'Página (como página de texto)';
$string['linkicon_file'] = 'Archivo (como actividad de archivo)';
$string['linkicon_book'] = 'Libro';
$string['linkicon_info'] = 'Información';
$string['linkicon_news'] = 'Noticias';
$string['linkicon_help'] = 'Ayuda';
$string['linkicon_globe'] = 'Web / globo';
$string['linkicon_group'] = 'Grupo / equipo';
$string['linkicon_calendar'] = 'Calendario/evento';
$string['linkicon_comment'] = 'Diálogo / comentario';
$string['element_slot'] = 'ID de ranura';
$string['view_element'] = 'Contenido de la página principal';
$string['back_to_frontpage'] = 'Volver al inicio del sitio';
$string['disabled'] = 'Los elementos de la página principal están deshabilitados.';
$string['frontpage_element_choice'] = 'ZSK: {$a}';
$string['no_elements'] = 'Aún no se han creado elementos de portada.';
$string['element_created'] = 'Elemento de portada creado.';
$string['element_updated'] = 'Elemento de la página principal guardado.';
$string['element_deleted'] = 'Elemento de la página principal eliminado.';
$string['invalidelement'] = 'Elemento de la página principal no encontrado.';
$string['privacy:metadata'] = 'El complemento almacena el contenido de la página principal creado por los administradores. No se almacenan datos personales de los visitantes.';

// Auto-synced missing keys from en.

$string['cli_seed_heading'] = 'Seed config defaults (local_zsk_frontpage_elements)';
$string['cli_seed_static_count'] = '{$a} static defaults written.';
$string['cli_seed_static_none'] = 'No missing static defaults.';
$string['cli_seed_admin_count'] = '{$a} admin defaults initialised.';
$string['cli_seed_warnings'] = 'Warnings:';
$string['cli_seed_no_pending'] = 'No open upgradesettings for this plugin.';
$string['cli_seed_still_pending'] = 'Still pending:';
$string['cli_seed_next_steps'] = 'Next steps:';
$string['cli_seed_step_cookies'] = 'Clear browser cookies for this site';
$string['cli_seed_step_reload'] = 'Open /admin or the site home again (do not bookmark upgradesettings.php)';
