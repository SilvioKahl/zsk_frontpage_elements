<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lang/ru/local_zsk_frontpage_elements.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Пользовательские элементы главной страницы ZSK';
$string['zsk_frontpage_elements:manage'] = 'Manage ZSK custom front page elements';
$string['admin_category'] = 'Пользовательские элементы главной страницы ZSK';
$string['settings'] = 'Настройки';
$string['settings_intro'] = 'Создавайте собственные разделы контента для главной страницы сайта и свободно размещайте их в настройках главной страницы Moodle.';
$string['settings_enabled'] = 'Включить плагин';
$string['settings_enabled_desc'] = 'Если этот параметр отключен, настраиваемые элементы главной страницы не отображаются и не предлагаются в настройках главной страницы.';
$string['manage_elements'] = 'Управление элементами главной страницы';
$string['manage_intro'] = 'Создайте здесь текстовые и медиа-разделы. Используйте «Как ссылку» для текстовых страниц и «Как ссылку на файл» для PDF-файлов и документов. Затем разместите их свободно в разделе «Администрирование сайта» → «Главная страница» → «Настройки главной страницы».';
$string['frontpage_settings_link'] = 'Открыть настройки главной страницы';
$string['add_element'] = 'Добавить элемент';
$string['edit_element'] = 'Редактировать элемент';
$string['element_name'] = 'Заголовок';
$string['element_content'] = 'Содержание';
$string['element_displaymode'] = 'Показать на главной странице сайта';
$string['element_displaymode_help'] = '«Прямо на главной странице сайта» показывает заголовок и контент в блоке. «Как ссылка (отдельная страница)» показывает только кликабельный заголовок; контент отображается на отдельной странице. «Как ссылка на файл» открывает файл напрямую — либо загруженный в Moodle, либо через внешний URL-адрес (например, PDF).';
$string['displaymode_inline'] = 'Прямо на сайте дома';
$string['displaymode_link'] = 'По ссылке (отдельная страница)';
$string['displaymode_file'] = 'Как ссылка на файл (например, PDF)';
$string['element_filesource'] = 'Источник файла';
$string['element_filesource_help'] = 'Выберите, загрузить ли файл в Moodle или связать его с внешним адресом.';
$string['filesource_upload'] = 'Загрузить файл';
$string['filesource_external'] = 'Внешний URL-адрес';
$string['element_externallink'] = 'Внешний URL-адрес';
$string['element_externallink_help'] = 'Полный адрес файла (http:// или https://), например. PDF-файл, размещенный в другом месте.';
$string['element_attachment'] = 'Файл';
$string['element_attachment_help'] = 'Загрузите один файл (например, PDF). Щелчок по заголовку на главной странице сайта открывает файл напрямую.';
$string['element_linkicon'] = 'Значок ссылки';
$string['element_linkicon_help'] = 'Значок отображается рядом с заголовком ссылки на главной странице сайта. Для ссылок на файлы рекомендуется использовать «Файл».';
$string['linkicon_page'] = 'Страница (например, текстовая страница)';
$string['linkicon_file'] = 'Файл (например, активность файла)';
$string['linkicon_book'] = 'Книга';
$string['linkicon_info'] = 'Информация';
$string['linkicon_news'] = 'Новости';
$string['linkicon_help'] = 'Помощь';
$string['linkicon_globe'] = 'Паутина/глобус';
$string['linkicon_group'] = 'Группа/команда';
$string['linkicon_calendar'] = 'Календарь/событие';
$string['linkicon_comment'] = 'Диалог/комментарий';
$string['element_slot'] = 'Идентификатор слота';
$string['view_element'] = 'Содержимое главной страницы';
$string['back_to_frontpage'] = 'Вернуться на главную страницу сайта';
$string['disabled'] = 'Элементы главной страницы отключены.';
$string['frontpage_element_choice'] = 'ЗСК: {$a}';
$string['no_elements'] = 'Элементы главной страницы пока не созданы.';
$string['element_created'] = 'Элемент главной страницы создан.';
$string['element_updated'] = 'Элемент главной страницы сохранен.';
$string['element_deleted'] = 'Элемент главной страницы удален.';
$string['invalidelement'] = 'Элемент главной страницы не найден.';
$string['privacy:metadata'] = 'Плагин хранит содержимое главной страницы, созданное администраторами. Никакие персональные данные посетителей не сохраняются.';

// Auto-synced missing keys from en.

$string['cli_seed_heading'] = 'Seed config defaults (local_zsk_frontpage_elements)';
$string['cli_seed_static_count'] = '{$a} static defaults written.';
$string['cli_seed_static_none'] = 'No missing static defaults.';
$string['cli_seed_admin_count'] = '{$a} admin defaults initialised.';
$string['cli_seed_warnings'] = 'Warnings:';
$string['cli_seed_no_pending'] = 'No open upgradesettings for this plugin.';
$string['cli_seed_still_pending'] = 'Still pending:';
$string['cli_seed_next_steps'] = 'Next steps:';
$string['cli_seed_step_cookies'] = 'Clear browser cookies for this site';
$string['cli_seed_step_reload'] = 'Open /admin or the site home again (do not bookmark upgradesettings.php)';
