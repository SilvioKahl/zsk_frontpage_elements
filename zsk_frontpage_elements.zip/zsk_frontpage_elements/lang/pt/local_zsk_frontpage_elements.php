<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lang/pt/local_zsk_frontpage_elements.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Elementos personalizados da primeira página ZSK';
$string['zsk_frontpage_elements:manage'] = 'Manage ZSK custom front page elements';
$string['admin_category'] = 'Elementos personalizados da primeira página ZSK';
$string['settings'] = 'Configurações';
$string['settings_intro'] = 'Crie seções de conteúdo personalizadas para a página inicial do site e coloque-as livremente nas configurações da página inicial do Moodle.';
$string['settings_enabled'] = 'Habilitar plug-in';
$string['settings_enabled_desc'] = 'Quando desativado, os elementos personalizados da primeira página não são mostrados ou oferecidos nas configurações da primeira página.';
$string['manage_elements'] = 'Gerenciar elementos da primeira página';
$string['manage_intro'] = 'Crie seções de texto e mídia aqui. Use “Como link” para páginas de texto e “Como link de arquivo” para PDFs e documentos. Em seguida, coloque-os livremente em Administração do site → Primeira página → Configurações da primeira página.';
$string['frontpage_settings_link'] = 'Abra as configurações da primeira página';
$string['add_element'] = 'Adicionar elemento';
$string['edit_element'] = 'Editar elemento';
$string['element_name'] = 'Título';
$string['element_content'] = 'Contente';
$string['element_displaymode'] = 'Exibir na página inicial do site';
$string['element_displaymode_help'] = '“Diretamente na página inicial do site” mostra o título e o conteúdo do bloco. “Como link (página separada)” mostra apenas um título clicável; o conteúdo aparece em sua própria página. “Como link de arquivo” abre um arquivo diretamente – carregado no Moodle ou através de um URL externo (por exemplo, PDF).';
$string['displaymode_inline'] = 'Diretamente na página inicial';
$string['displaymode_link'] = 'Como link (página separada)';
$string['displaymode_file'] = 'Como link de arquivo (por exemplo, PDF)';
$string['element_filesource'] = 'Fonte do arquivo';
$string['element_filesource_help'] = 'Escolha se deseja fazer upload de um arquivo no Moodle ou vincular a um endereço externo.';
$string['filesource_upload'] = 'Carregar arquivo';
$string['filesource_external'] = 'URL externo';
$string['element_externallink'] = 'URL externo';
$string['element_externallink_help'] = 'Endereço completo do arquivo (http:// ou https://), por ex. um PDF hospedado em outro lugar.';
$string['element_attachment'] = 'Arquivo';
$string['element_attachment_help'] = 'Carregue um arquivo (por exemplo, PDF). Clicar no título na página inicial do site abre o arquivo diretamente.';
$string['element_linkicon'] = 'Ícone de link';
$string['element_linkicon_help'] = 'Ícone mostrado ao lado do link do título na página inicial do site. Para links de arquivos, “Arquivo” é recomendado.';
$string['linkicon_page'] = 'Página (como página de texto)';
$string['linkicon_file'] = 'Arquivo (como atividade de arquivo)';
$string['linkicon_book'] = 'Livro';
$string['linkicon_info'] = 'Informação';
$string['linkicon_news'] = 'Notícias';
$string['linkicon_help'] = 'Ajuda';
$string['linkicon_globe'] = 'Web / globo';
$string['linkicon_group'] = 'Grupo/equipe';
$string['linkicon_calendar'] = 'Calendário / evento';
$string['linkicon_comment'] = 'Diálogo / comentário';
$string['element_slot'] = 'ID do slot';
$string['view_element'] = 'Conteúdo da primeira página';
$string['back_to_frontpage'] = 'Voltar para a página inicial do site';
$string['disabled'] = 'Os elementos da primeira página estão desativados.';
$string['frontpage_element_choice'] = 'ZSK: {$a}';
$string['no_elements'] = 'Nenhum elemento de primeira página foi criado ainda.';
$string['element_created'] = 'Elemento de primeira página criado.';
$string['element_updated'] = 'Elemento da primeira página salvo.';
$string['element_deleted'] = 'Elemento da primeira página excluído.';
$string['invalidelement'] = 'Elemento da primeira página não encontrado.';
$string['privacy:metadata'] = 'O plugin armazena conteúdo da primeira página criado por administradores. Nenhum dado pessoal do visitante é armazenado.';

// Auto-synced missing keys from en.

$string['cli_seed_heading'] = 'Seed config defaults (local_zsk_frontpage_elements)';
$string['cli_seed_static_count'] = '{$a} static defaults written.';
$string['cli_seed_static_none'] = 'No missing static defaults.';
$string['cli_seed_admin_count'] = '{$a} admin defaults initialised.';
$string['cli_seed_warnings'] = 'Warnings:';
$string['cli_seed_no_pending'] = 'No open upgradesettings for this plugin.';
$string['cli_seed_still_pending'] = 'Still pending:';
$string['cli_seed_next_steps'] = 'Next steps:';
$string['cli_seed_step_cookies'] = 'Clear browser cookies for this site';
$string['cli_seed_step_reload'] = 'Open /admin or the site home again (do not bookmark upgradesettings.php)';
