<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lang/fr/local_zsk_frontpage_elements.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Éléments de page d\'accueil personnalisés ZSK';
$string['zsk_frontpage_elements:manage'] = 'Manage ZSK custom front page elements';
$string['admin_category'] = 'Éléments de page d\'accueil personnalisés ZSK';
$string['settings'] = 'Paramètres';
$string['settings_intro'] = 'Créez des sections de contenu personnalisées pour l\'accueil du site et placez-les librement dans les paramètres de la page d\'accueil de Moodle.';
$string['settings_enabled'] = 'Activer le plug-in';
$string['settings_enabled_desc'] = 'Lorsqu\'ils sont désactivés, les éléments personnalisés de la page d\'accueil ne sont pas affichés ni proposés dans les paramètres de la page d\'accueil.';
$string['manage_elements'] = 'Gérer les éléments de la première page';
$string['manage_intro'] = 'Créez ici des sections de texte et de médias. Utilisez « Comme lien » pour les pages de texte et « Comme lien de fichier » pour les PDF et les documents. Placez-les ensuite librement sous Administration du site → Première page → Paramètres de la première page.';
$string['frontpage_settings_link'] = 'Ouvrir les paramètres de la première page';
$string['add_element'] = 'Ajouter un élément';
$string['edit_element'] = 'Modifier l\'élément';
$string['element_name'] = 'Titre';
$string['element_content'] = 'Contenu';
$string['element_displaymode'] = 'Affichage sur place accueil';
$string['element_displaymode_help'] = '« Directement sur site accueil » affiche le titre et le contenu du bloc. « En tant que lien (page séparée) » affiche uniquement un titre cliquable ; le contenu apparaît sur sa propre page. « En tant que lien de fichier » ouvre un fichier directement – ​​soit téléchargé dans Moodle, soit via une URL externe (par exemple PDF).';
$string['displaymode_inline'] = 'Directement sur place à la maison';
$string['displaymode_link'] = 'Sous forme de lien (page séparée)';
$string['displaymode_file'] = 'Comme lien de fichier (par exemple PDF)';
$string['element_filesource'] = 'Origine du fichier';
$string['element_filesource_help'] = 'Choisissez si vous souhaitez télécharger un fichier dans Moodle ou créer un lien vers une adresse externe.';
$string['filesource_upload'] = 'Télécharger le fichier';
$string['filesource_external'] = 'URL externe';
$string['element_externallink'] = 'URL externe';
$string['element_externallink_help'] = 'Adresse complète du fichier (http:// ou https://), par ex. un PDF hébergé ailleurs.';
$string['element_attachment'] = 'Déposer';
$string['element_attachment_help'] = 'Téléchargez un fichier (par exemple PDF). Cliquer sur le titre sur l\'accueil du site ouvre directement le fichier.';
$string['element_linkicon'] = 'Icône de lien';
$string['element_linkicon_help'] = 'Icône affichée à côté du lien du titre sur l\'accueil du site. Pour les liens de fichiers, « Fichier » est recommandé.';
$string['linkicon_page'] = 'Page (comme une page de texte)';
$string['linkicon_file'] = 'Fichier (comme l\'activité du fichier)';
$string['linkicon_book'] = 'Livre';
$string['linkicon_info'] = 'Information';
$string['linkicon_news'] = 'Nouvelles';
$string['linkicon_help'] = 'Aide';
$string['linkicon_globe'] = 'Web/monde';
$string['linkicon_group'] = 'Groupe / équipe';
$string['linkicon_calendar'] = 'Calendrier / événement';
$string['linkicon_comment'] = 'Dialogue / commentaire';
$string['element_slot'] = 'ID d\'emplacement';
$string['view_element'] = 'Contenu de la première page';
$string['back_to_frontpage'] = 'Retour à l\'accueil du site';
$string['disabled'] = 'Les éléments de la première page sont désactivés.';
$string['frontpage_element_choice'] = 'ZSK : {$a}';
$string['no_elements'] = 'Aucun élément de première page n\'a encore été créé.';
$string['element_created'] = 'Élément de première page créé.';
$string['element_updated'] = 'Élément de première page enregistré.';
$string['element_deleted'] = 'Élément de première page supprimé.';
$string['invalidelement'] = 'Élément de première page introuvable.';
$string['privacy:metadata'] = 'Le plugin stocke le contenu de la première page créé par les administrateurs. Aucune donnée personnelle des visiteurs n\'est stockée.';

// Auto-synced missing keys from en.

$string['cli_seed_heading'] = 'Seed config defaults (local_zsk_frontpage_elements)';
$string['cli_seed_static_count'] = '{$a} static defaults written.';
$string['cli_seed_static_none'] = 'No missing static defaults.';
$string['cli_seed_admin_count'] = '{$a} admin defaults initialised.';
$string['cli_seed_warnings'] = 'Warnings:';
$string['cli_seed_no_pending'] = 'No open upgradesettings for this plugin.';
$string['cli_seed_still_pending'] = 'Still pending:';
$string['cli_seed_next_steps'] = 'Next steps:';
$string['cli_seed_step_cookies'] = 'Clear browser cookies for this site';
$string['cli_seed_step_reload'] = 'Open /admin or the site home again (do not bookmark upgradesettings.php)';
