<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lang/de/local_zsk_frontpage_elements.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'ZSK eigene Startseiten-Elemente';
$string['zsk_frontpage_elements:manage'] = 'ZSK eigene Startseiten-Elemente verwalten';
$string['admin_category'] = 'ZSK eigene Startseiten-Elemente';
$string['settings'] = 'Einstellungen';
$string['settings_intro'] = 'Eigene Inhaltsbereiche für die Startseite erstellen und in den Startseiten-Einstellungen von Moodle frei einsortieren.';
$string['settings_enabled'] = 'Plugin aktivieren';
$string['settings_enabled_desc'] = 'Wenn deaktiviert, werden keine eigenen Startseiten-Elemente angezeigt oder in den Startseiten-Einstellungen angeboten.';
$string['manage_elements'] = 'Startseiten-Elemente verwalten';
$string['manage_intro'] = 'Legen Sie hier Text- und Medienbereiche an. „Als Link“ für Textseiten, „Als Datei-Link“ für PDFs und Dokumente. Anschließend frei einordnen unter Website-Administration → Startseite → Startseite-Einstellungen.';
$string['frontpage_settings_link'] = 'Zu den Startseiten-Einstellungen';
$string['add_element'] = 'Element hinzufügen';
$string['edit_element'] = 'Element bearbeiten';
$string['element_name'] = 'Titel';
$string['element_content'] = 'Inhalt';
$string['element_displaymode'] = 'Anzeige auf der Startseite';
$string['element_displaymode_help'] = '„Direkt auf der Startseite“ zeigt Titel und Inhalt im Block. „Als Link (eigene Seite)“ zeigt nur einen klickbaren Titel; der Inhalt erscheint auf einer eigenen Seite. „Als Datei-Link“ öffnet eine Datei direkt – entweder hochgeladen oder über eine externe URL (z. B. PDF).';
$string['displaymode_inline'] = 'Direkt auf der Startseite';
$string['displaymode_link'] = 'Als Link (eigene Seite)';
$string['displaymode_file'] = 'Als Datei-Link (z. B. PDF)';
$string['element_filesource'] = 'Dateiquelle';
$string['element_filesource_help'] = 'Wählen Sie, ob die Datei in Moodle hochgeladen oder über eine externe Adresse verlinkt werden soll.';
$string['filesource_upload'] = 'Datei hochladen';
$string['filesource_external'] = 'Externe URL';
$string['element_externallink'] = 'Externe URL';
$string['element_externallink_help'] = 'Vollständige Adresse zur Datei (http:// oder https://), z. B. ein PDF auf einem anderen Server.';
$string['element_attachment'] = 'Datei';
$string['element_attachment_help'] = 'Eine Datei hochladen (z. B. PDF). Beim Klick auf den Titel auf der Startseite wird die Datei direkt geöffnet.';
$string['element_linkicon'] = 'Link-Symbol';
$string['element_linkicon_help'] = 'Symbol neben dem Titel-Link auf der Startseite. Bei Datei-Links empfiehlt sich „Datei“.';
$string['linkicon_page'] = 'Seite (wie Textseite)';
$string['linkicon_file'] = 'Datei (wie Datei-Aktivität)';
$string['linkicon_book'] = 'Buch';
$string['linkicon_info'] = 'Information';
$string['linkicon_news'] = 'Neuigkeiten';
$string['linkicon_help'] = 'Hilfe';
$string['linkicon_globe'] = 'Web / Welt';
$string['linkicon_group'] = 'Gruppe / Team';
$string['linkicon_calendar'] = 'Kalender / Termin';
$string['linkicon_comment'] = 'Dialog / Kommentar';
$string['element_slot'] = 'Slot-ID';
$string['view_element'] = 'Startseiten-Inhalt';
$string['back_to_frontpage'] = 'Zurück zur Startseite';
$string['disabled'] = 'Startseiten-Elemente sind deaktiviert.';
$string['frontpage_element_choice'] = 'ZSK: {$a}';
$string['no_elements'] = 'Noch keine Startseiten-Elemente angelegt.';
$string['element_created'] = 'Startseiten-Element wurde angelegt.';
$string['element_updated'] = 'Startseiten-Element wurde gespeichert.';
$string['element_deleted'] = 'Startseiten-Element wurde gelöscht.';
$string['invalidelement'] = 'Startseiten-Element nicht gefunden.';
$string['privacy:metadata'] = 'Das Plugin speichert von Administratoren erstellte Startseiten-Inhalte. Es werden keine personenbezogenen Nutzerdaten der Seitenbesucher gespeichert.';

$string['cli_seed_heading'] = 'Konfigurations-Defaults setzen (local_zsk_frontpage_elements)';
$string['cli_seed_static_count'] = '{$a} statische Defaults geschrieben.';
$string['cli_seed_static_none'] = 'Keine fehlenden statischen Defaults.';
$string['cli_seed_admin_count'] = '{$a} Admin-Defaults initialisiert.';
$string['cli_seed_warnings'] = 'Warnungen:';
$string['cli_seed_no_pending'] = 'Keine offenen upgradesettings für dieses Plugin.';
$string['cli_seed_still_pending'] = 'Noch offen:';
$string['cli_seed_next_steps'] = 'Nächste Schritte:';
$string['cli_seed_step_cookies'] = 'Browser-Cookies für diese Website löschen';
$string['cli_seed_step_reload'] = '/admin oder Startseite erneut öffnen (upgradesettings.php nicht bookmarken)';
