<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
local_zsk_frontpage_elements_require_manage();

$id = required_param('id', PARAM_INT);
require_sesskey();

$element = local_zsk_frontpage_elements_get_element($id);
if (!$element) {
    throw new moodle_exception('invalidelement', 'local_zsk_frontpage_elements');
}

global $DB;
local_zsk_frontpage_elements_delete_element_files($id);
$DB->delete_records('local_zsk_frontpage_elements', ['id' => $id]);
local_zsk_frontpage_elements_remove_slot_from_config($id);

redirect(
    new moodle_url('/local/zsk_frontpage_elements/manage.php'),
    get_string('element_deleted', 'local_zsk_frontpage_elements'),
    null,
    \core\output\notification::NOTIFY_SUCCESS
);
