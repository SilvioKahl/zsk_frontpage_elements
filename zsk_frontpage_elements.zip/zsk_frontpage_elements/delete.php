<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (delete.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
local_zsk_frontpage_elements_require_manage();

$id = required_param('id', PARAM_INT);
require_sesskey();

$element = local_zsk_frontpage_elements_get_element($id);
if (!$element) {
    throw new moodle_exception('invalidelement', 'local_zsk_frontpage_elements');
}

global $DB;
local_zsk_frontpage_elements_delete_element_files($id);
$DB->delete_records('local_zsk_frontpage_elements', ['id' => $id]);
local_zsk_frontpage_elements_remove_slot_from_config($id);

redirect(
    new moodle_url('/local/zsk_frontpage_elements/manage.php'),
    get_string('element_deleted', 'local_zsk_frontpage_elements'),
    null,
    \core\output\notification::NOTIFY_SUCCESS
);
