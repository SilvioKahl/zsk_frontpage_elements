<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @return bool
 */
function xmldb_local_zsk_frontpage_elements_install() {
    global $CFG;

    require_once($CFG->dirroot . '/local/zsk_frontpage_elements/lib.php');
    local_zsk_frontpage_elements_seed_config_defaults();

    return true;
}
