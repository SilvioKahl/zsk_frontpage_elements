<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$callbacks = [
    [
        'hook' => \core\hook\output\before_footer_html_generation::class,
        'callback' => [\local_zsk_frontpage_elements\hook_callbacks::class, 'inject_frontpage_elements'],
        'priority' => 600,
    ],
];

if (class_exists(\core\hook\output\before_standard_head_html_generation::class)) {
    $callbacks[] = [
        'hook' => \core\hook\output\before_standard_head_html_generation::class,
        'callback' => [\local_zsk_frontpage_elements\hook_callbacks::class, 'register_page_styles'],
    ];
}
