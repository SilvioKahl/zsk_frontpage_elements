<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_zsk_frontpage_elements_upgrade($oldversion) {
    global $CFG;

    require_once($CFG->dirroot . '/local/zsk_frontpage_elements/lib.php');

    if ($oldversion < 2025060301) {
        local_zsk_frontpage_elements_seed_config_defaults();

        upgrade_plugin_savepoint(true, 2025060301, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060302) {
        upgrade_plugin_savepoint(true, 2025060302, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060307) {
        upgrade_plugin_savepoint(true, 2025060307, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060308) {
        local_zsk_frontpage_elements_seed_config_defaults();
        upgrade_plugin_savepoint(true, 2025060308, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060309) {
        upgrade_plugin_savepoint(true, 2025060309, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060310) {
        upgrade_plugin_savepoint(true, 2025060310, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060311) {
        upgrade_plugin_savepoint(true, 2025060311, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060312) {
        upgrade_plugin_savepoint(true, 2025060312, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060313) {
        upgrade_plugin_savepoint(true, 2025060313, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060314) {
        upgrade_plugin_savepoint(true, 2025060314, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060315) {
        global $DB;
        $dbman = $DB->get_manager();

        $table = new xmldb_table('local_zsk_frontpage_elements');
        $field = new xmldb_field(
            'displaymode',
            XMLDB_TYPE_INTEGER,
            '2',
            null,
            XMLDB_NOTNULL,
            null,
            '0',
            'contentformat'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_plugin_savepoint(true, 2025060315, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060316) {
        upgrade_plugin_savepoint(true, 2025060316, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060317) {
        upgrade_plugin_savepoint(true, 2025060317, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060318) {
        global $DB;
        $dbman = $DB->get_manager();

        $table = new xmldb_table('local_zsk_frontpage_elements');
        $field = new xmldb_field(
            'linkicon',
            XMLDB_TYPE_CHAR,
            '32',
            null,
            XMLDB_NOTNULL,
            null,
            'page',
            'displaymode'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_plugin_savepoint(true, 2025060318, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060319) {
        upgrade_plugin_savepoint(true, 2025060319, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060320) {
        upgrade_plugin_savepoint(true, 2025060320, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060321) {
        global $DB;
        $dbman = $DB->get_manager();

        $table = new xmldb_table('local_zsk_frontpage_elements');

        $field = new xmldb_field(
            'filesource',
            XMLDB_TYPE_INTEGER,
            '2',
            null,
            XMLDB_NOTNULL,
            null,
            '0',
            'linkicon'
        );
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field(
            'externallink',
            XMLDB_TYPE_CHAR,
            '1333',
            null,
            XMLDB_NOTNULL,
            null,
            '',
            'filesource'
        );
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_plugin_savepoint(true, 2025060321, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060323) {
        upgrade_plugin_savepoint(true, 2025060323, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060324) {
        upgrade_plugin_savepoint(true, 2025060324, 'local', 'zsk_frontpage_elements');
    }

    return true;
}
