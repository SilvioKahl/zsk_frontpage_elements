<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (db/upgrade.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_zsk_frontpage_elements_upgrade($oldversion) {
    global $CFG;

    require_once($CFG->dirroot . '/local/zsk_frontpage_elements/lib.php');

    if ($oldversion < 2025060301) {
        local_zsk_frontpage_elements_seed_config_defaults();

        upgrade_plugin_savepoint(true, 2025060301, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060302) {
        upgrade_plugin_savepoint(true, 2025060302, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060307) {
        upgrade_plugin_savepoint(true, 2025060307, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060308) {
        local_zsk_frontpage_elements_seed_config_defaults();
        upgrade_plugin_savepoint(true, 2025060308, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060309) {
        upgrade_plugin_savepoint(true, 2025060309, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060310) {
        upgrade_plugin_savepoint(true, 2025060310, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060311) {
        upgrade_plugin_savepoint(true, 2025060311, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060312) {
        upgrade_plugin_savepoint(true, 2025060312, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060313) {
        upgrade_plugin_savepoint(true, 2025060313, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060314) {
        upgrade_plugin_savepoint(true, 2025060314, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060315) {
        global $DB;
        $dbman = $DB->get_manager();

        $table = new xmldb_table('local_zsk_frontpage_elements');
        $field = new xmldb_field(
            'displaymode',
            XMLDB_TYPE_INTEGER,
            '2',
            null,
            XMLDB_NOTNULL,
            null,
            '0',
            'contentformat'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_plugin_savepoint(true, 2025060315, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060316) {
        upgrade_plugin_savepoint(true, 2025060316, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060317) {
        upgrade_plugin_savepoint(true, 2025060317, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060318) {
        global $DB;
        $dbman = $DB->get_manager();

        $table = new xmldb_table('local_zsk_frontpage_elements');
        $field = new xmldb_field(
            'linkicon',
            XMLDB_TYPE_CHAR,
            '32',
            null,
            XMLDB_NOTNULL,
            null,
            'page',
            'displaymode'
        );

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_plugin_savepoint(true, 2025060318, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060319) {
        upgrade_plugin_savepoint(true, 2025060319, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060320) {
        upgrade_plugin_savepoint(true, 2025060320, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060321) {
        global $DB;
        $dbman = $DB->get_manager();

        $table = new xmldb_table('local_zsk_frontpage_elements');

        $field = new xmldb_field(
            'filesource',
            XMLDB_TYPE_INTEGER,
            '2',
            null,
            XMLDB_NOTNULL,
            null,
            '0',
            'linkicon'
        );
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field(
            'externallink',
            XMLDB_TYPE_CHAR,
            '1333',
            null,
            XMLDB_NOTNULL,
            null,
            '',
            'filesource'
        );
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_plugin_savepoint(true, 2025060321, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060323) {
        upgrade_plugin_savepoint(true, 2025060323, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025060324) {
        upgrade_plugin_savepoint(true, 2025060324, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025070906) {
        upgrade_plugin_savepoint(true, 2025070906, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025073100) {
        upgrade_plugin_savepoint(true, 2025073100, 'local', 'zsk_frontpage_elements');
    }

    if ($oldversion < 2025073101) {
        upgrade_plugin_savepoint(true, 2025073101, 'local', 'zsk_frontpage_elements');
    }

    return true;
}
