<?php
// This file is part of Moodle - http://moodle.org/

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

if (!local_zsk_frontpage_elements_is_enabled()) {
    throw new moodle_exception('disabled', 'local_zsk_frontpage_elements');
}

$element = local_zsk_frontpage_elements_get_element($id);
if (!$element) {
    throw new moodle_exception('invalidelement', 'local_zsk_frontpage_elements');
}

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_frontpage_elements/view.php', ['id' => $id]));
$PAGE->set_pagelayout('standard');

$title = format_string($element->name);
$PAGE->set_title($title);
$PAGE->set_heading($title);

$PAGE->navbar->add(get_string('home'), new moodle_url('/'));
$PAGE->navbar->add($title);

local_zsk_frontpage_elements_require_styles();

$content = local_zsk_frontpage_elements_format_element_content($element);
if (trim(strip_tags($content)) === '') {
    throw new moodle_exception('invalidelement', 'local_zsk_frontpage_elements');
}

echo $OUTPUT->header();
echo html_writer::div(
    html_writer::link(
        new moodle_url('/'),
        '« ' . get_string('back_to_frontpage', 'local_zsk_frontpage_elements'),
        ['class' => 'local-zsk-fp-back-link']
    ),
    'mb-3'
);
echo html_writer::div($content, 'local-zsk-fp-element-content local-zsk-fp-element-view');
echo $OUTPUT->footer();
