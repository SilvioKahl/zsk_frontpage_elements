<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Public view of a front page element shown as a link.
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

// Guests may view front page content when the site allows guest access.
require_login(null, true);

if (!local_zsk_frontpage_elements_is_enabled()) {
    throw new moodle_exception('disabled', 'local_zsk_frontpage_elements');
}

$element = local_zsk_frontpage_elements_get_element($id);
if (!$element) {
    throw new moodle_exception('invalidelement', 'local_zsk_frontpage_elements');
}

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_frontpage_elements/view.php', ['id' => $id]));
$PAGE->set_pagelayout('standard');

$title = format_string($element->name);
$PAGE->set_title($title);
$PAGE->set_heading($title);

$PAGE->navbar->add(get_string('home'), new moodle_url('/'));
$PAGE->navbar->add($title);

local_zsk_frontpage_elements_require_styles();

$content = local_zsk_frontpage_elements_format_element_content($element);
if (trim(strip_tags($content)) === '') {
    throw new moodle_exception('invalidelement', 'local_zsk_frontpage_elements');
}

/** @var \local_zsk_frontpage_elements\output\renderer $renderer */
$renderer = $PAGE->get_renderer('local_zsk_frontpage_elements');

echo $OUTPUT->header();
echo $renderer->render_element_view([
    'backurl' => (new moodle_url('/'))->out(false),
    'backlabel' => get_string('back_to_frontpage', 'local_zsk_frontpage_elements'),
    'content' => $content,
]);
echo $OUTPUT->footer();
