// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Place front page elements in the centre column layout order.
 *
 * @module     local_zsk_frontpage_elements/frontpage_layout
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {

    /**
     * @param {string[]} layoutSlots
     * @param {string} searchSlot
     */
    const init = (layoutSlots, searchSlot) => {
        const slots = Array.isArray(layoutSlots) ? layoutSlots : [];
        const skipSlot = searchSlot || '7';
        const placedAttr = 'data-zsk-fp-placed';

        const getPlacementContainer = () => {
            const regionmain = document.querySelector('#region-main');
            if (!regionmain) {
                return null;
            }
            return regionmain.querySelector('[role="main"]') || regionmain;
        };

        const findCourseSearchBox = (container) => {
            const form = container.querySelector('form[action*="course/search"]');
            if (!form) {
                return null;
            }
            return form.closest('.box') || form.parentElement;
        };

        const insertAfter = (newNode, refNode) => {
            if (!refNode) {
                const container = getPlacementContainer();
                if (!container) {
                    return;
                }
                container.insertBefore(newNode, container.firstChild);
                return;
            }
            const parent = refNode.parentNode;
            if (!parent) {
                return;
            }
            if (refNode.nextSibling) {
                parent.insertBefore(newNode, refNode.nextSibling);
            } else {
                parent.appendChild(newNode);
            }
        };

        const findPending = (slot) => {
            return document.querySelector('[data-zsk-fp-placement-pending][data-layout-slot="' + slot + '"]');
        };

        const finalizePending = (pending) => {
            pending.classList.remove(
                'local-zsk-fp-element-pending',
                'local-termine-frontpage-pending',
                'local-zsk-tiles-frontpage-pending'
            );
            pending.removeAttribute('id');
            pending.removeAttribute('data-zsk-fp-placement-pending');
            pending.setAttribute(placedAttr, '1');
        };

        const placeByLayoutOrder = () => {
            const container = getPlacementContainer();
            if (!container) {
                return false;
            }

            if (!document.querySelector('[data-zsk-fp-placement-pending]')) {
                return false;
            }

            let anchor = findCourseSearchBox(container);
            let moved = false;

            slots.forEach((slot) => {
                if (slot === skipSlot) {
                    return;
                }

                const pending = findPending(slot);
                if (!pending) {
                    return;
                }

                finalizePending(pending);
                insertAfter(pending, anchor);
                anchor = pending;
                moved = true;
            });

            return moved;
        };

        const schedulePlacement = () => {
            [0, 120, 400, 1200, 2500].forEach((delay) => {
                setTimeout(placeByLayoutOrder, delay);
            });
        };

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', schedulePlacement);
        } else {
            schedulePlacement();
        }

        document.addEventListener('local-zsk-tiles-tiles-rendered', placeByLayoutOrder);
    };

    return {
        init: init,
    };
});
