<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (manage.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use local_zsk_frontpage_elements\form\element_form;

require_login();
local_zsk_frontpage_elements_require_manage();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_frontpage_elements/manage.php'));
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('manage_elements', 'local_zsk_frontpage_elements'));
$PAGE->set_heading(get_string('manage_elements', 'local_zsk_frontpage_elements'));

echo $OUTPUT->header();

echo $OUTPUT->heading(get_string('manage_elements', 'local_zsk_frontpage_elements'));
echo html_writer::div(get_string('manage_intro', 'local_zsk_frontpage_elements'), 'mb-3');
echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/zsk_frontpage_elements/edit.php'),
        get_string('add_element', 'local_zsk_frontpage_elements'),
        ['class' => 'btn btn-primary mb-3']
    ) . ' ' .
    html_writer::link(
        new moodle_url('/admin/settings.php', ['section' => 'frontpagesettings']),
        get_string('frontpage_settings_link', 'local_zsk_frontpage_elements'),
        ['class' => 'btn btn-secondary mb-3']
    )
);

$elements = local_zsk_frontpage_elements_get_all_elements();

if (empty($elements)) {
    echo $OUTPUT->notification(get_string('no_elements', 'local_zsk_frontpage_elements'), 'info');
    echo $OUTPUT->footer();
    exit;
}

$table = new html_table();
$table->head = [
    get_string('element_name', 'local_zsk_frontpage_elements'),
    get_string('element_displaymode', 'local_zsk_frontpage_elements'),
    get_string('element_slot', 'local_zsk_frontpage_elements'),
    get_string('actions'),
];
$table->data = [];

foreach ($elements as $element) {
    $slot = \local_zsk_frontpage_elements\frontpage::slot_for_element((int) $element->id);
    $actions = html_writer::link(
        new moodle_url('/local/zsk_frontpage_elements/edit.php', ['id' => $element->id]),
        get_string('edit')
    );
    $actions .= ' | ' . html_writer::link(
        new moodle_url('/local/zsk_frontpage_elements/delete.php', [
            'id' => $element->id,
            'sesskey' => sesskey(),
        ]),
        get_string('delete'),
        ['class' => 'text-danger']
    );

    $table->data[] = [
        format_string($element->name),
        local_zsk_frontpage_elements_get_display_mode_label($element),
        $slot,
        $actions,
    ];
}

echo html_writer::table($table);
echo $OUTPUT->footer();
