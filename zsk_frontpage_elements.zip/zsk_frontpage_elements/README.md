# Custom site home elements (`local_zsk_frontpage_elements`)

Moodle local plugin to add flexible, centrally managed content blocks to the **site home** (front page): welcome texts, linked info pages, and direct file links (PDFs). Elements appear in Moodle’s front page settings as sortable items alongside the course list, course tiles, and other front page components.

## Features

- **Three display modes per element**
  - Inline on the site home (title + HTML content)
  - Link to a separate page (title only on the home page)
  - File link (uploaded file or external URL, e.g. PDF)
- **Sortable placement** in Moodle front page settings (`frontpage` / `frontpageloggedin`)
- **Separate configuration** for guests and logged-in users
- **Link icons** (page, file, calendar, info, and more) for link and file elements
- **HTML editor** with embedded images; file manager for uploads
- **Central administration** via capability `local/zsk_frontpage_elements:manage` (managers by default)
- **Optional ZSK integration** with course tiles / events plugins when they are installed separately (they register their own front page picker entries)
- **Privacy API** provider included
- **German and English** language packs

No other Moodle plugins are required. There are no `$plugin->dependencies`.

## Git repository naming

For a public GitHub/GitLab repo, prefer:

```text
moodle-local_zsk_frontpage_elements
```

The install folder inside Moodle remains `local/zsk_frontpage_elements/`.

## Requirements

| Requirement | Version |
|-------------|---------|
| Moodle | 4.1 or later (4.4+ recommended for navigation hooks) |
| PHP | As required by your Moodle version |
| Database | MySQL, MariaDB, PostgreSQL, or SQL Server (standard Moodle) |

## Installation

1. Copy the folder `zsk_frontpage_elements` to `moodle/local/zsk_frontpage_elements/`.
2. Log in as administrator and open **Site administration → Notifications** to run the upgrade.
3. Purge caches if needed.
4. Create elements under **Site administration → ZSK custom site home elements → Manage elements**.
5. Add each element to the site home under **Site administration → Front page settings** (items named `ZSK: [title]`).

### ZIP layout (important)

After extracting the ZIP, the path must be:

```text
moodle/local/zsk_frontpage_elements/version.php
```

The ZIP must contain the folder `zsk_frontpage_elements/`, not the plugin files directly at the archive root.

## Documentation

| Document | Description |
|----------|-------------|
| [docs/en/INSTALLATION_ADMIN.md](docs/en/INSTALLATION_ADMIN.md) | Installation, front page layout, display modes, troubleshooting |
| [docs/en/PRODUCT_DESCRIPTION.md](docs/en/PRODUCT_DESCRIPTION.md) | Problems solved and benefits for operators |
| [docs/de/INSTALLATION_ADMIN.md](docs/de/INSTALLATION_ADMIN.md) | German admin guide |
| [docs/de/PRODUKTBESCHREIBUNG.md](docs/de/PRODUKTBESCHREIBUNG.md) | German product description |
| [docs/en/README.md](docs/en/README.md) | Full documentation index (English) |
| [docs/de/README.md](docs/de/README.md) | Full documentation index (German) |

## Main URLs

| Page | Path |
|------|------|
| Manage elements | `/local/zsk_frontpage_elements/manage.php` |
| Edit element | `/local/zsk_frontpage_elements/edit.php` |
| View element (link mode) | `/local/zsk_frontpage_elements/view.php` |
| Seed defaults (CLI) | `php local/zsk_frontpage_elements/cli/seed_defaults.php` |

## Capabilities

| Capability | Purpose |
|------------|---------|
| `local/zsk_frontpage_elements:manage` | Create, edit, delete elements and manage plugin settings |

## Uninstallation

Uninstalling removes plugin tables and configuration. Moodle courses and user content are not affected.

## License

GNU GPL v3 or later.

## Author

Silvio Kuhn – [die-schulungsexperten.de](https://die-schulungsexperten.de)

## Changelog / release notes

### 1.4.4 (2025060324)

- Stable release for moodle.org submission
- Documentation and admin guides (DE/EN)
- Config seed defaults on upgrade to avoid missing `config_plugins` entries

### 1.4.3 (2025060323)

- Front page hook integration improvements
- Recovery page for missing plugin configuration

### 1.4.2 (2025060321)

- **File source:** upload in Moodle or external URL for file-link elements
- Database fields `filesource` and `externallink`

### 1.4.1 (2025060318)

- **Link icons** selectable for link and file elements (`linkicon` field)

### 1.4.0 (2025060315)

- **Display modes:** inline, separate page, file link (`displaymode` field)
- Element form and rendering for all three modes

### 1.3.x and earlier

- Initial plugin: custom front page elements, management UI, guest/logged-in front page slots
- Integration hooks for ZSK tiles and events plugins
- CLI `seed_defaults.php` for configuration defaults

Full history: [CHANGELOG.md](CHANGELOG.md).
