<?php
// This file is part of Moodle - http://moodle.org/
//
// Emergency recovery when admin/upgradesettings.php causes ERR_TOO_MANY_REDIRECTS.
// No SSH required — call once in the browser, then DELETE this file.
//
// URL example:
//   https://your-moodle.site/local/zsk_frontpage_elements/recover_config.php?token=CHANGE_ME
//
// Set RECOVERY_TOKEN below before upload (random string). Delete this file after success.

define('ABORT_AFTER_CONFIG', true);

require(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/moodlelib.php');
require_once($CFG->libdir . '/weblib.php');
require_once(__DIR__ . '/classes/config_seed.php');

use local_zsk_frontpage_elements\config_seed;

// Change this to a random secret before uploading, e.g. bin2hex(random_bytes(16)).
const RECOVERY_TOKEN = 'zsk-recover-change-me';

$token = optional_param('token', '', PARAM_ALPHANUMEXT);
if ($token === '' || !hash_equals(RECOVERY_TOKEN, $token)) {
    header('HTTP/1.1 403 Forbidden');
    header('Content-Type: text/plain; charset=utf-8');
    echo "Forbidden. Use ?token=… (see recover_config.php on server).\n";
    exit;
}

$result = config_seed::apply_static_defaults();
$adminwritten = [];
$errors = [];
$pending = [];

try {
    $admin = config_seed::apply_admin_defaults();
    $adminwritten = $admin['written'];
    $errors = $admin['errors'];
    $pending = config_seed::get_pending_settings();
} catch (Throwable $e) {
    $errors[] = 'Admin-Initialisierung übersprungen: ' . $e->getMessage();
}

$result = [
    'written' => $result['written'],
    'admin_written' => $adminwritten,
    'errors' => $errors,
    'pending' => $pending,
];

header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html><html lang="de"><head><meta charset="utf-8"><title>ZSK Config Recovery</title>';
echo '<style>body{font-family:sans-serif;max-width:48rem;margin:2rem auto;line-height:1.5}';
echo 'code{background:#f4f4f4;padding:.1rem .3rem}ul{font-size:.9rem}</style></head><body>';
echo '<h1>ZSK Config Recovery</h1>';

if (!empty($result['written'])) {
    echo '<p><strong>' . count($result['written']) . ' statische Defaults gesetzt.</strong></p><ul>';
    foreach ($result['written'] as $line) {
        echo '<li><code>' . s($line) . '</code></li>';
    }
    echo '</ul>';
} else {
    echo '<p>Keine fehlenden statischen Defaults.</p>';
}

if (!empty($result['admin_written'])) {
    echo '<p><strong>' . count($result['admin_written']) . ' Admin-Defaults initialisiert.</strong></p><ul>';
    foreach ($result['admin_written'] as $line) {
        echo '<li><code>' . s($line) . '</code></li>';
    }
    echo '</ul>';
}

if (!empty($result['errors'])) {
    echo '<p><strong>Warnungen:</strong></p><ul>';
    foreach ($result['errors'] as $line) {
        echo '<li>' . s($line) . '</li>';
    }
    echo '</ul>';
}

if (empty($result['pending'])) {
    echo '<p style="color:green"><strong>Keine offenen upgradesettings für ZSK-Plugins.</strong></p>';
} else {
    echo '<p style="color:#a60"><strong>Noch offen:</strong></p><ul>';
    foreach ($result['pending'] as $line) {
        echo '<li><code>' . s($line) . '</code></li>';
    }
    echo '</ul>';
}

echo '<h2>Nächste Schritte</h2><ol>';
echo '<li>Cookies für diese Website im Browser löschen</li>';
echo '<li>Startseite neu laden (nicht <code>/admin/upgradesettings.php</code> bookmarken)</li>';
echo '<li><strong>Diese Datei <code>recover_config.php</code> vom Server löschen!</strong></li>';
echo '</ol></body></html>';
