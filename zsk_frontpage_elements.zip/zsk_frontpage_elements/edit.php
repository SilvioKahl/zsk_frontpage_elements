<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (edit.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/filelib.php');
require_once($CFG->libdir . '/formslib.php');
require_once(__DIR__ . '/lib.php');

use local_zsk_frontpage_elements\form\element_form;
use local_zsk_frontpage_elements\frontpage;

require_login();
local_zsk_frontpage_elements_require_manage();

$id = optional_param('id', 0, PARAM_INT);

$context = context_system::instance();
$editoroptions = local_zsk_frontpage_elements_get_editor_options();
$filemanageroptions = local_zsk_frontpage_elements_get_filemanager_options();

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/zsk_frontpage_elements/edit.php', ['id' => $id]));
$PAGE->set_pagelayout('admin');

$element = null;
if ($id > 0) {
    $element = local_zsk_frontpage_elements_get_element($id);
    if (!$element) {
        throw new moodle_exception('invalidelement', 'local_zsk_frontpage_elements');
    }
    $PAGE->set_title(get_string('edit_element', 'local_zsk_frontpage_elements'));
    $PAGE->set_heading(get_string('edit_element', 'local_zsk_frontpage_elements'));
} else {
    $PAGE->set_title(get_string('add_element', 'local_zsk_frontpage_elements'));
    $PAGE->set_heading(get_string('add_element', 'local_zsk_frontpage_elements'));
}

$form = new element_form(null, [
    'editoroptions' => $editoroptions,
    'filemanageroptions' => $filemanageroptions,
]);

if ($element) {
    $element = file_prepare_standard_editor(
        $element,
        'content',
        $editoroptions,
        $context,
        'local_zsk_frontpage_elements',
        'content',
        $element->id
    );
    $element = file_prepare_standard_filemanager(
        $element,
        'attachment',
        $filemanageroptions,
        $context,
        'local_zsk_frontpage_elements',
        'attachment',
        $element->id
    );
    $form->set_data($element);
} else {
    $defaults = (object) [
        'content' => '',
        'contentformat' => FORMAT_HTML,
    ];
    $defaults = file_prepare_standard_editor(
        $defaults,
        'content',
        $editoroptions,
        $context,
        'local_zsk_frontpage_elements',
        'content',
        0
    );
    $defaults = file_prepare_standard_filemanager(
        $defaults,
        'attachment',
        $filemanageroptions,
        $context,
        'local_zsk_frontpage_elements',
        'attachment',
        0
    );
    $defaults->id = 0;
    $defaults->name = '';
    $defaults->displaymode = frontpage::DISPLAY_INLINE;
    $defaults->linkicon = 'page';
    $defaults->filesource = frontpage::FILESOURCE_UPLOAD;
    $defaults->externallink = '';
    $form->set_data($defaults);
}

if ($form->is_cancelled()) {
    redirect(new moodle_url('/local/zsk_frontpage_elements/manage.php'));
}

if ($data = $form->get_data()) {
    global $DB, $USER;

    require_sesskey();

    $now = time();
    $displaymode = local_zsk_frontpage_elements_normalize_displaymode($data->displaymode ?? 0);
    $linkicon = local_zsk_frontpage_elements_normalize_linkicon((string) ($data->linkicon ?? 'page'));
    $filesource = local_zsk_frontpage_elements_normalize_filesource((int) ($data->filesource ?? 0));
    $externallink = '';
    if ($displaymode === frontpage::DISPLAY_FILE) {
        if ($filesource === frontpage::FILESOURCE_EXTERNAL) {
            $externallink = local_zsk_frontpage_elements_normalize_external_link((string) ($data->externallink ?? ''));
        }
        if ($linkicon === 'page') {
            $linkicon = 'file';
        }
    }

    if (empty($data->id)) {
        $data->id = (int) $DB->insert_record('local_zsk_frontpage_elements', (object) [
            'name' => $data->name,
            'content' => '',
            'contentformat' => FORMAT_HTML,
            'displaymode' => $displaymode,
            'linkicon' => $linkicon,
            'filesource' => $filesource,
            'externallink' => $externallink,
            'timemodified' => $now,
            'usermodified' => $USER->id,
        ]);
        $message = get_string('element_created', 'local_zsk_frontpage_elements');
    } else {
        $message = get_string('element_updated', 'local_zsk_frontpage_elements');
    }

    if ($displaymode === frontpage::DISPLAY_FILE) {
        if ($filesource === frontpage::FILESOURCE_UPLOAD) {
            local_zsk_frontpage_elements_store_attachment_file($data, $data->id, $context, $filemanageroptions);
        }
        $contenttext = '';
        $contentformat = FORMAT_HTML;
    } else {
        $content = local_zsk_frontpage_elements_store_editor_content($data, $data->id, $context, $editoroptions);
        $contenttext = $content['text'];
        $contentformat = $content['format'];
    }

    $DB->update_record('local_zsk_frontpage_elements', (object) [
        'id' => $data->id,
        'name' => $data->name,
        'content' => $contenttext,
        'contentformat' => $contentformat,
        'displaymode' => $displaymode,
        'linkicon' => $linkicon,
        'filesource' => $filesource,
        'externallink' => $externallink,
        'timemodified' => $now,
        'usermodified' => $USER->id,
    ]);

    redirect(
        new moodle_url('/local/zsk_frontpage_elements/manage.php'),
        $message,
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

echo $OUTPUT->header();
$form->display();
echo $OUTPUT->footer();
