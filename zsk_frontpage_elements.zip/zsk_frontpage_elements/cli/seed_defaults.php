<?php



// This file is part of Moodle - http://moodle.org/



//



// Seeds config_plugins rows for ZSK plugins so admin/upgradesettings.php does not loop.



//



// Usage (from Moodle root):



//   php admin/cli/upgrade.php --non-interactive



//   php local/zsk_frontpage_elements/cli/seed_defaults.php



//



// Without SSH: upload recover_config.php and open it in the browser (see file header).







define('CLI_SCRIPT', true);







require(__DIR__ . '/../../../config.php');



require_once($CFG->libdir . '/clilib.php');



require_once(__DIR__ . '/../classes/config_seed.php');







use local_zsk_frontpage_elements\config_seed;







$result = config_seed::apply_all();







foreach ($result['written'] as $line) {

    cli_writeln("Gesetzt: {$line}");

}



foreach ($result['admin_written'] as $line) {

    cli_writeln("Initialisiert: {$line}");

}



foreach ($result['errors'] as $line) {

    cli_writeln("Warnung: {$line}");

}







$fixed = count($result['written']) + count($result['admin_written']);







if ($fixed === 0) {

    cli_writeln('Keine fehlenden Standardwerte gefunden.');

} else {

    cli_writeln("Fertig: {$fixed} Eintrag/Einträge ergänzt oder initialisiert.");

}







cli_writeln('');



cli_writeln('Prüfe noch offene upgradesettings …');







if (empty($result['pending'])) {

    cli_writeln('Keine offenen upgradesettings-Einstellungen für ZSK-Plugins.');

} else {

    cli_writeln('Noch offen:');

    foreach ($result['pending'] as $line) {

        cli_writeln('  - ' . $line);

    }

}







cli_writeln('');



cli_writeln('Nächste Schritte:');



cli_writeln('  1. Browser-Cookies für die Site löschen');



cli_writeln('  2. /admin oder Startseite erneut aufrufen (nicht upgradesettings.php direkt bookmarken)');


