<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * CLI: seed missing plugin config defaults.
 *
 * Usage (from Moodle root):
 *   php local/zsk_frontpage_elements/cli/seed_defaults.php
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('CLI_SCRIPT', true);

require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/clilib.php');
require_once(__DIR__ . '/../classes/config_seed.php');

use local_zsk_frontpage_elements\config_seed;

$result = config_seed::apply_all();

cli_heading(get_string('cli_seed_heading', 'local_zsk_frontpage_elements'));

if (!empty($result['written'])) {
    cli_writeln(get_string('cli_seed_static_count', 'local_zsk_frontpage_elements', count($result['written'])));
    foreach ($result['written'] as $line) {
        cli_writeln('  - ' . $line);
    }
} else {
    cli_writeln(get_string('cli_seed_static_none', 'local_zsk_frontpage_elements'));
}

if (!empty($result['admin_written'])) {
    cli_writeln(get_string('cli_seed_admin_count', 'local_zsk_frontpage_elements', count($result['admin_written'])));
    foreach ($result['admin_written'] as $line) {
        cli_writeln('  - ' . $line);
    }
}

if (!empty($result['errors'])) {
    cli_writeln(get_string('cli_seed_warnings', 'local_zsk_frontpage_elements'));
    foreach ($result['errors'] as $line) {
        cli_problem($line);
    }
}

if (empty($result['pending'])) {
    cli_writeln(get_string('cli_seed_no_pending', 'local_zsk_frontpage_elements'));
} else {
    cli_writeln(get_string('cli_seed_still_pending', 'local_zsk_frontpage_elements'));
    foreach ($result['pending'] as $line) {
        cli_writeln('  - ' . $line);
    }
}

cli_writeln('');
cli_writeln(get_string('cli_seed_next_steps', 'local_zsk_frontpage_elements'));
cli_writeln('  1. ' . get_string('cli_seed_step_cookies', 'local_zsk_frontpage_elements'));
cli_writeln('  2. ' . get_string('cli_seed_step_reload', 'local_zsk_frontpage_elements'));

exit(0);
