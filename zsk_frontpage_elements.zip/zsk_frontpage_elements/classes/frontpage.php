<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_frontpage_elements;

defined('MOODLE_INTERNAL') || die();

/**
 * Front page centre-column integration.
 */
class frontpage {

    /** @var int Show full content directly on the site home. */
    public const DISPLAY_INLINE = 0;

    /** @var int Show only a title link on the site home; content on view.php. */
    public const DISPLAY_LINK = 1;

    /** @var int Show a title link that opens an uploaded file directly (e.g. PDF). */
    public const DISPLAY_FILE = 2;

    /** @var int File link uses an uploaded file in Moodle. */
    public const FILESOURCE_UPLOAD = 0;

    /** @var int File link uses an external URL. */
    public const FILESOURCE_EXTERNAL = 1;

    /** @var int Slot values start above core and other ZSK plugins (tiles=8, termine=9). */
    public const SLOT_BASE = 10000;

    /** @var string Moodle {@see FRONTPAGECOURSESEARCH} – rendered outside centre-column placement. */
    public const LAYOUT_SLOT_COURSE_SEARCH = '7';

    /** @var string ZSK course tiles slot ({@see \local_zsk_local_tiles\frontpage::FRONTPAGECOURSETILES}). */
    public const LAYOUT_SLOT_COURSE_TILES = '8';

    /** @var string ZSK upcoming events slot ({@see \local_zsk_termine\frontpage::FRONTPAGETERMINE}). */
    public const LAYOUT_SLOT_TERMINE = '9';

    /**
     * @param int $elementid
     * @return string
     */
    public static function slot_for_element(int $elementid): string {
        return (string) (self::SLOT_BASE + $elementid);
    }

    /**
     * @param string $slot
     * @return int|false
     */
    public static function element_id_from_slot(string $slot): int|false {
        $slot = trim($slot);
        if ($slot === '' || !ctype_digit($slot)) {
            return false;
        }
        $value = (int) $slot;
        if ($value < self::SLOT_BASE) {
            return false;
        }
        return $value - self::SLOT_BASE;
    }

    /**
     * @param string $slot
     * @return bool
     */
    public static function is_custom_element_slot(string $slot): bool {
        return self::element_id_from_slot($slot) !== false;
    }

    /**
     * @param bool $loggedin
     * @return string[]
     */
    public static function get_layout_slots(bool $loggedin = true): array {
        global $CFG;

        $key = $loggedin ? 'frontpageloggedin' : 'frontpage';
        $layout = isset($CFG->$key) ? (string) $CFG->$key : '';
        if ($layout === '') {
            return [];
        }

        $slots = [];
        foreach (explode(',', $layout) as $slot) {
            $slot = trim($slot);
            if ($slot !== '' && $slot !== 'none') {
                $slots[] = $slot;
            }
        }

        return $slots;
    }

    /**
     * Element ids selected for the current front page context.
     *
     * @param bool $loggedin
     * @return int[]
     */
    public static function get_selected_element_ids(bool $loggedin = true): array {
        $ids = [];
        foreach (self::get_layout_slots($loggedin) as $slot) {
            $id = self::element_id_from_slot($slot);
            if ($id !== false) {
                $ids[] = $id;
            }
        }

    return array_values(array_unique($ids));
}

    /**
     * Layout slots that are not repositioned via the centre-column selector (e.g. course search).
     *
     * @param string $slot
     * @return bool
     */
    public static function is_centre_column_layout_slot(string $slot): bool {
        return $slot !== '' && $slot !== self::LAYOUT_SLOT_COURSE_SEARCH;
    }

    /**
     * Zero-based position among centre-column front page blocks (excluding course search).
     *
     * @param string $slot
     * @param bool $loggedin
     * @return int|false
     */
    public static function get_centre_column_slot_index(string $slot, bool $loggedin = true): int|false {
        $centreindex = 0;
        foreach (self::get_layout_slots($loggedin) as $layoutslot) {
            if ($layoutslot === $slot) {
                return $centreindex;
            }
            if (self::is_centre_column_layout_slot($layoutslot)) {
                $centreindex++;
            }
        }

        return false;
    }

    /**
     * @param int $elementid
     * @param bool $loggedin
     * @return int|false
     */
    public static function get_element_slot_index(int $elementid, bool $loggedin = true): int|false {
        return self::get_centre_column_slot_index(self::slot_for_element($elementid), $loggedin);
    }

    /**
     * Whether the logged-in front page layout includes blocks placed by the coordinator script.
     *
     * @param bool $loggedin
     * @return bool
     */
    public static function layout_needs_coordinator(bool $loggedin = true): bool {
        foreach (self::get_layout_slots($loggedin) as $slot) {
            if ($slot === self::LAYOUT_SLOT_COURSE_SEARCH) {
                continue;
            }
            if (self::is_custom_element_slot($slot)
                || $slot === self::LAYOUT_SLOT_TERMINE
                || $slot === self::LAYOUT_SLOT_COURSE_TILES) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param \stdClass $element
     * @return bool
     */
    public static function is_link_display(\stdClass $element): bool {
        return (int) ($element->displaymode ?? self::DISPLAY_INLINE) === self::DISPLAY_LINK;
    }

    /**
     * @param \stdClass $element
     * @return bool
     */
    public static function is_file_display(\stdClass $element): bool {
        return (int) ($element->displaymode ?? self::DISPLAY_INLINE) === self::DISPLAY_FILE;
    }

    /**
     * @param \stdClass $element
     * @return string
     */
    public static function render_element_section(\stdClass $element): string {
        if (self::is_file_display($element)) {
            return self::render_element_file_link($element);
        }

        if (self::is_link_display($element)) {
            return self::render_element_link($element);
        }

        return self::render_element_inline($element);
    }

    /**
     * @param \stdClass $element
     * @return string
     */
    protected static function render_element_inline(\stdClass $element): string {
        global $OUTPUT;

        $content = local_zsk_frontpage_elements_format_element_content($element);
        if (trim(strip_tags($content)) === '') {
            return '';
        }

        $title = format_string($element->name);
        $sectionid = 'frontpage-zsk-element-' . (int) $element->id;

        $html = \html_writer::link(
            '#skip' . $sectionid,
            get_string('skipa', 'access', \core_text::strtolower(strip_tags($title))),
            ['class' => 'skip-block skip aabtn']
        );
        $html .= \html_writer::start_tag('div', [
            'id' => $sectionid,
            'class' => 'local-zsk-fp-element-section',
            'data-zsk-fp-element' => (string) (int) $element->id,
        ]);
        $html .= $OUTPUT->heading($title, 2, 'local-zsk-fp-element-title');
        $html .= \html_writer::div($content, 'local-zsk-fp-element-content');
        $html .= \html_writer::end_tag('div');
        $html .= \html_writer::tag('span', '', ['class' => 'skip-block-to', 'id' => 'skip' . $sectionid]);

        return $html;
    }

    /**
     * @param \stdClass $element
     * @return string
     */
    protected static function render_element_link(\stdClass $element): string {
        $title = format_string($element->name);
        if ($title === '') {
            return '';
        }

        $sectionid = 'frontpage-zsk-element-' . (int) $element->id;
        $url = new \moodle_url('/local/zsk_frontpage_elements/view.php', ['id' => (int) $element->id]);

        $html = \html_writer::link(
            '#skip' . $sectionid,
            get_string('skipa', 'access', \core_text::strtolower(strip_tags($title))),
            ['class' => 'skip-block skip aabtn']
        );
        $html .= \html_writer::start_tag('div', [
            'id' => $sectionid,
            'class' => 'local-zsk-fp-element-section local-zsk-fp-element-link',
            'data-zsk-fp-element' => (string) (int) $element->id,
        ]);
        $linklabel = local_zsk_frontpage_elements_render_link_icon($element);
        $linklabel .= \html_writer::span($title, 'local-zsk-fp-element-link-text');
        $html .= \html_writer::link($url, $linklabel, ['class' => 'local-zsk-fp-element-link-anchor']);
        $html .= \html_writer::end_tag('div');
        $html .= \html_writer::tag('span', '', ['class' => 'skip-block-to', 'id' => 'skip' . $sectionid]);

        return $html;
    }

    /**
     * @param \stdClass $element
     * @return string
     */
    protected static function render_element_file_link(\stdClass $element): string {
        $title = format_string($element->name);
        if ($title === '') {
            return '';
        }

        $filetarget = local_zsk_frontpage_elements_get_element_file_link_target($element);
        if ($filetarget === null) {
            return '';
        }

        $sectionid = 'frontpage-zsk-element-' . (int) $element->id;
        $linkattrs = ['class' => 'local-zsk-fp-element-link-anchor'];
        if (!empty($filetarget['external'])) {
            $linkattrs['target'] = '_blank';
            $linkattrs['rel'] = 'noopener noreferrer';
        }

        $html = \html_writer::link(
            '#skip' . $sectionid,
            get_string('skipa', 'access', \core_text::strtolower(strip_tags($title))),
            ['class' => 'skip-block skip aabtn']
        );
        $html .= \html_writer::start_tag('div', [
            'id' => $sectionid,
            'class' => 'local-zsk-fp-element-section local-zsk-fp-element-link local-zsk-fp-element-file',
            'data-zsk-fp-element' => (string) (int) $element->id,
        ]);
        $linklabel = local_zsk_frontpage_elements_render_link_icon($element);
        $linklabel .= \html_writer::span($title, 'local-zsk-fp-element-link-text');
        $html .= \html_writer::link($filetarget['url'], $linklabel, $linkattrs);
        $html .= \html_writer::end_tag('div');
        $html .= \html_writer::tag('span', '', ['class' => 'skip-block-to', 'id' => 'skip' . $sectionid]);

        return $html;
    }

    /**
     * CSS selector for all sortable front page centre elements.
     *
     * @return string
     */
    public static function get_sortable_selector(): string {
        return '#site-news-forum, #frontpage-course-list, #frontpage-available-course-list, ' .
            '#frontpage-category-names, #frontpage-category-combo, #frontpage-course-tiles, ' .
            '#frontpage-upcoming-events, .local-zsk-fp-element-section';
    }
}
