<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_frontpage_elements\admin;

defined('MOODLE_INTERNAL') || die();

/**
 * Admin navigation for ZSK front page elements.
 */
class admin_nav {

    public const CATEGORY = 'zsklocalfrontpageelements';

    /**
     * @param \admin_root $admin
     * @return void
     */
    public static function ensure_category(\admin_root $admin): void {
        static $done = false;
        if ($done || $admin->locate(self::CATEGORY, false)) {
            $done = true;
            return;
        }

        $insertbefore = null;
        foreach (['aisettings', 'ai', 'analytics'] as $candidate) {
            if ($admin->locate($candidate, false)) {
                $insertbefore = $candidate;
                break;
            }
        }

        $category = new \admin_category(self::CATEGORY, get_string('admin_category', 'local_zsk_frontpage_elements'));
        if ($insertbefore !== null) {
            $admin->add('root', $category, $insertbefore);
        } else {
            $admin->add('root', $category);
        }
        $done = true;
    }

    /**
     * @param \admin_root $admin
     * @param \admin_externalpage|\admin_settingpage $page
     * @return void
     */
    public static function add_page(\admin_root $admin, $page): void {
        self::ensure_category($admin);
        $admin->add(self::CATEGORY, $page);
    }
}
