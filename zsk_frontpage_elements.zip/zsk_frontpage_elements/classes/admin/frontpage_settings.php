<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (classes/admin/frontpage_settings.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_zsk_frontpage_elements\admin;

defined('MOODLE_INTERNAL') || die();

/**
 * Patch core front page settings to include ZSK custom elements.
 */
class frontpage_settings {

    /**
     * @return void
     */
    public static function patch_admin_tree(): void {
        global $ADMIN;

        if (!isset($ADMIN) || self::is_unsafe_admin_context()) {
            return;
        }

        self::replace_setting_on_page($ADMIN, 'frontpagesettings', 'frontpageloggedin', true);
        self::replace_setting_on_page($ADMIN, 'frontpagesettings', 'frontpage', false);
    }

    /**
     * Skip patching during upgrade, plugin install/uninstall and new-settings save flows.
     *
     * @return bool
     */
    protected static function is_unsafe_admin_context(): bool {
        if (during_initial_install()) {
            return true;
        }

        if (defined('CLI_SCRIPT') && CLI_SCRIPT) {
            return true;
        }

        $script = (string) ($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
        if ($script === '') {
            return false;
        }

        $basename = basename($script);
        $unsafe = [
            'upgradesettings.php',
            'upgrade.php',
            'install.php',
            'plugins.php',
            'plugin_package_installer.php',
            'uninstall.php',
        ];

        return in_array($basename, $unsafe, true);
    }

    /**
     * @param \admin_root $admin
     * @param string $pageid
     * @param string $settingname
     * @param bool $loggedin
     * @return void
     */
    protected static function replace_setting_on_page(
        \admin_root $admin,
        string $pageid,
        string $settingname,
        bool $loggedin
    ): void {
        $page = $admin->locate($pageid, false);
        if (!$page || !($page instanceof \admin_settingpage)) {
            return;
        }

        if (empty($page->settings)) {
            return;
        }

        foreach ($page->settings as $key => $setting) {
            if (!($setting instanceof \admin_setting_courselist_frontpage)) {
                continue;
            }
            if ($setting instanceof frontpage_courselist) {
                return;
            }
            if ($setting instanceof \local_zsk_frontpage_elements\admin\frontpage_courselist) {
                return;
            }
            if ($setting->name !== $settingname) {
                continue;
            }

            if (is_object($page->settings)) {
                $page->settings->{$key} = new frontpage_courselist($loggedin);
            } else {
                $page->settings[$key] = new frontpage_courselist($loggedin);
            }
            return;
        }
    }
}
