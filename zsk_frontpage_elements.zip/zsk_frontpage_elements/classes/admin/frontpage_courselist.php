<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_frontpage_elements\admin;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/adminlib.php');

/**
 * Extends front page element lists with ZSK custom elements and related plugins.
 */
class frontpage_courselist extends \admin_setting_courselist_frontpage {

    /**
     * @return bool
     */
    public function load_choices() {
        if (is_array($this->choices)) {
            return true;
        }

        parent::load_choices();
        self::append_zsk_choices($this->choices);

        return true;
    }

    /**
     * @param array $choices
     * @return void
     */
    public static function append_zsk_choices(array &$choices): void {
        if (class_exists(\local_zsk_local_tiles\frontpage::class)) {
            $key = \local_zsk_local_tiles\frontpage::FRONTPAGECOURSETILES;
            $choices[$key] = get_string('frontpagecoursetiles', 'local_zsk_local_tiles');
        } else if (class_exists(\local_tiles2\frontpage::class)) {
            $key = \local_tiles2\frontpage::FRONTPAGECOURSETILES;
            $choices[$key] = get_string('frontpagecoursetiles', 'local_tiles2');
        }

        if (class_exists(\local_zsk_termine\frontpage::class)) {
            $key = \local_zsk_termine\frontpage::FRONTPAGETERMINE;
            $choices[$key] = get_string('frontpagetermine', 'local_zsk_termine');
        }

        self::append_custom_elements($choices);
    }

    /**
     * @param array $choices
     * @return void
     */
    public static function append_custom_elements(array &$choices): void {
        if (!function_exists('local_zsk_frontpage_elements_is_enabled')
            || !local_zsk_frontpage_elements_is_enabled()) {
            return;
        }

        foreach (local_zsk_frontpage_elements_get_all_elements() as $element) {
            $slot = \local_zsk_frontpage_elements\frontpage::slot_for_element((int) $element->id);
            $choices[$slot] = get_string('frontpage_element_choice', 'local_zsk_frontpage_elements', format_string($element->name));
        }
    }
}
