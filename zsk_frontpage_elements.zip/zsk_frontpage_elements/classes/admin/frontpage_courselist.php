<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (classes/admin/frontpage_courselist.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_zsk_frontpage_elements\admin;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/adminlib.php');

/**
 * Extends front page element lists with this plugin's custom elements.
 */
class frontpage_courselist extends \admin_setting_courselist_frontpage {

    /**
     * @return bool
     */
    public function load_choices() {
        if (is_array($this->choices)) {
            return true;
        }

        parent::load_choices();
        self::append_zsk_choices($this->choices);

        return true;
    }

    /**
     * @param array $choices
     * @return void
     */
    public static function append_zsk_choices(array &$choices): void {
        // Only this plugin's elements are added here.
        // Optional companions (tiles, termine) register their own front page choices.
        self::append_custom_elements($choices);
    }

    /**
     * @param array $choices
     * @return void
     */
    public static function append_custom_elements(array &$choices): void {
        if (!function_exists('local_zsk_frontpage_elements_is_enabled')
            || !local_zsk_frontpage_elements_is_enabled()) {
            return;
        }

        foreach (local_zsk_frontpage_elements_get_all_elements() as $element) {
            $slot = \local_zsk_frontpage_elements\frontpage::slot_for_element((int) $element->id);
            $choices[$slot] = get_string('frontpage_element_choice', 'local_zsk_frontpage_elements', format_string($element->name));
        }
    }
}
