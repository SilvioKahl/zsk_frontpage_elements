<?php

// This file is part of Moodle - http://moodle.org/



namespace local_zsk_frontpage_elements;



defined('MOODLE_INTERNAL') || die();



require_once(__DIR__ . '/../lib.php');



/**

 * Hook callbacks for front page element injection.

 */

class hook_callbacks {



    /**

     * @param \core\hook\output\before_standard_head_html_generation $hook

     * @return void

     */

    public static function register_page_styles(

        \core\hook\output\before_standard_head_html_generation $hook

    ): void {

        global $PAGE;



        if ($PAGE->pagetype !== 'site-index' || !local_zsk_frontpage_elements_is_enabled()) {

            return;

        }



        if (!frontpage::layout_needs_coordinator(isloggedin() && !isguestuser())) {

            return;

        }



        $late = local_zsk_frontpage_elements_require_styles();

        if ($late !== '') {

            $hook->add_html($late);

        }

    }



    /**

     * @param \core\hook\output\before_footer_html_generation $hook

     * @return void

     */

    public static function inject_frontpage_elements(

        \core\hook\output\before_footer_html_generation $hook

    ): void {

        global $PAGE;



        if ($PAGE->pagetype !== 'site-index' || !local_zsk_frontpage_elements_is_enabled()) {

            return;

        }



        $loggedin = isloggedin() && !isguestuser();

        if (!frontpage::layout_needs_coordinator($loggedin)) {

            return;

        }



        $pendinghtml = '';

        foreach (frontpage::get_selected_element_ids($loggedin) as $elementid) {

            $element = local_zsk_frontpage_elements_get_element($elementid);

            if (!$element) {

                continue;

            }



            $section = frontpage::render_element_section($element);

            if ($section === '') {

                continue;

            }



            $pendinghtml .= \html_writer::div(

                $section,

                'local-zsk-fp-element-pending',

                [

                    'data-layout-slot' => frontpage::slot_for_element($elementid),

                    'data-zsk-fp-placement-pending' => '1',

                    'data-element-id' => (string) $elementid,

                ]

            );

        }



        if ($pendinghtml !== '') {

            $hook->add_html(local_zsk_frontpage_elements_require_styles() . $pendinghtml);

        }



        $PAGE->requires->js_init_code(self::frontpage_position_script($loggedin));

    }



    /**

     * @param bool $loggedin

     * @return string

     */

    protected static function frontpage_position_script(bool $loggedin): string {

        $layoutjson = json_encode(array_values(frontpage::get_layout_slots($loggedin)));



        return <<<JS

(function() {

    var layoutSlots = {$layoutjson};

    var searchSlot = '7';

    var placedAttr = 'data-zsk-fp-placed';



    function getPlacementContainer() {

        var regionmain = document.querySelector('#region-main');

        if (!regionmain) {

            return null;

        }

        return regionmain.querySelector('[role="main"]') || regionmain;

    }



    function findCourseSearchBox(container) {

        var form = container.querySelector('form[action*="course/search"]');

        if (!form) {

            return null;

        }

        return form.closest('.box') || form.parentElement;

    }



    function insertAfter(newNode, refNode) {

        if (!refNode) {

            var container = getPlacementContainer();

            if (!container) {

                return;

            }

            container.insertBefore(newNode, container.firstChild);

            return;

        }

        var parent = refNode.parentNode;

        if (!parent) {

            return;

        }

        if (refNode.nextSibling) {

            parent.insertBefore(newNode, refNode.nextSibling);

        } else {

            parent.appendChild(newNode);

        }

    }



    function findPending(slot) {

        return document.querySelector('[data-zsk-fp-placement-pending][data-layout-slot="' + slot + '"]');

    }



    function finalizePending(pending) {

        pending.classList.remove(

            'local-zsk-fp-element-pending',

            'local-termine-frontpage-pending',

            'local-zsk-tiles-frontpage-pending'

        );

        pending.removeAttribute('id');

        pending.removeAttribute('data-zsk-fp-placement-pending');

        pending.setAttribute(placedAttr, '1');

    }



    function placeByLayoutOrder() {

        var container = getPlacementContainer();

        if (!container) {

            return false;

        }



        if (!document.querySelector('[data-zsk-fp-placement-pending]')) {

            return false;

        }



        var anchor = findCourseSearchBox(container);

        var moved = false;



        layoutSlots.forEach(function(slot) {

            if (slot === searchSlot) {

                return;

            }



            var pending = findPending(slot);

            if (!pending) {

                return;

            }



            finalizePending(pending);

            insertAfter(pending, anchor);

            anchor = pending;

            moved = true;

        });



        return moved;

    }



    function schedulePlacement() {

        [0, 120, 400, 1200, 2500].forEach(function(delay) {

            setTimeout(placeByLayoutOrder, delay);

        });

    }



    if (document.readyState === 'loading') {

        document.addEventListener('DOMContentLoaded', schedulePlacement);

    } else {

        schedulePlacement();

    }



    document.addEventListener('local-zsk-tiles-tiles-rendered', placeByLayoutOrder);

})();

JS;

    }

}


