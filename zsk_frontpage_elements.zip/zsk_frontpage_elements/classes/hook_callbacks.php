<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (classes/hook_callbacks.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_zsk_frontpage_elements;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/../lib.php');

/**
 * Hook callbacks for front page element injection.
 */
class hook_callbacks {

    /**
     * @param \core\hook\output\before_standard_head_html_generation $hook
     * @return void
     */
    public static function register_page_styles(
        \core\hook\output\before_standard_head_html_generation $hook
    ): void {
        global $PAGE;

        if ($PAGE->pagetype !== 'site-index' || !local_zsk_frontpage_elements_is_enabled()) {
            return;
        }

        if (!frontpage::layout_needs_coordinator(isloggedin() && !isguestuser())) {
            return;
        }

        $late = local_zsk_frontpage_elements_require_styles();
        if ($late !== '') {
            $hook->add_html($late);
        }
    }

    /**
     * @param \core\hook\output\before_footer_html_generation $hook
     * @return void
     */
    public static function inject_frontpage_elements(
        \core\hook\output\before_footer_html_generation $hook
    ): void {
        global $PAGE;

        if ($PAGE->pagetype !== 'site-index' || !local_zsk_frontpage_elements_is_enabled()) {
            return;
        }

        $loggedin = isloggedin() && !isguestuser();
        if (!frontpage::layout_needs_coordinator($loggedin)) {
            return;
        }

        $pendinghtml = '';
        foreach (frontpage::get_selected_element_ids($loggedin) as $elementid) {
            $element = local_zsk_frontpage_elements_get_element($elementid);
            if (!$element) {
                continue;
            }

            $section = frontpage::render_element_section($element);
            if ($section === '') {
                continue;
            }

            $pendinghtml .= \html_writer::div(
                $section,
                'local-zsk-fp-element-pending',
                [
                    'data-layout-slot' => frontpage::slot_for_element($elementid),
                    'data-zsk-fp-placement-pending' => '1',
                    'data-element-id' => (string) $elementid,
                ]
            );
        }

        if ($pendinghtml !== '') {
            $hook->add_html(local_zsk_frontpage_elements_require_styles() . $pendinghtml);
            $PAGE->requires->js_call_amd(
                'local_zsk_frontpage_elements/frontpage_layout',
                'init',
                [
                    array_values(frontpage::get_layout_slots($loggedin)),
                    frontpage::LAYOUT_SLOT_COURSE_SEARCH,
                ]
            );
        }
    }
}
