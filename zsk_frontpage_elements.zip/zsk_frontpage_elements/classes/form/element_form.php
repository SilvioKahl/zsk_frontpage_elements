<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (classes/form/element_form.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_zsk_frontpage_elements\form;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/formslib.php');

/**
 * Form to create or edit a custom front page element.
 */
class element_form extends \moodleform {

    protected function definition() {
        $mform = $this->_form;
        $editoroptions = $this->_customdata['editoroptions'] ?? [];
        $filemanageroptions = $this->_customdata['filemanageroptions'] ?? [];

        $mform->addElement('hidden', 'id', 0);
        $mform->setType('id', PARAM_INT);

        $mform->addElement('text', 'name', get_string('element_name', 'local_zsk_frontpage_elements'), ['size' => 64]);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');

        $displayoptions = [
            \local_zsk_frontpage_elements\frontpage::DISPLAY_INLINE =>
                get_string('displaymode_inline', 'local_zsk_frontpage_elements'),
            \local_zsk_frontpage_elements\frontpage::DISPLAY_LINK =>
                get_string('displaymode_link', 'local_zsk_frontpage_elements'),
            \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE =>
                get_string('displaymode_file', 'local_zsk_frontpage_elements'),
        ];
        $mform->addElement(
            'select',
            'displaymode',
            get_string('element_displaymode', 'local_zsk_frontpage_elements'),
            $displayoptions
        );
        $mform->setType('displaymode', PARAM_INT);
        $mform->setDefault('displaymode', \local_zsk_frontpage_elements\frontpage::DISPLAY_INLINE);
        $mform->addHelpButton('displaymode', 'element_displaymode', 'local_zsk_frontpage_elements');

        $mform->addElement(
            'editor',
            'content_editor',
            get_string('element_content', 'local_zsk_frontpage_elements'),
            null,
            $editoroptions
        );
        $mform->setType('content_editor', PARAM_RAW);
        $mform->hideIf('content_editor', 'displaymode', 'eq', \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE);

        $filesourceoptions = [
            \local_zsk_frontpage_elements\frontpage::FILESOURCE_UPLOAD =>
                get_string('filesource_upload', 'local_zsk_frontpage_elements'),
            \local_zsk_frontpage_elements\frontpage::FILESOURCE_EXTERNAL =>
                get_string('filesource_external', 'local_zsk_frontpage_elements'),
        ];
        $mform->addElement(
            'select',
            'filesource',
            get_string('element_filesource', 'local_zsk_frontpage_elements'),
            $filesourceoptions
        );
        $mform->setType('filesource', PARAM_INT);
        $mform->setDefault('filesource', \local_zsk_frontpage_elements\frontpage::FILESOURCE_UPLOAD);
        $mform->addHelpButton('filesource', 'element_filesource', 'local_zsk_frontpage_elements');
        $mform->hideIf('filesource', 'displaymode', 'neq', \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE);

        $mform->addElement(
            'filemanager',
            'attachment_filemanager',
            get_string('element_attachment', 'local_zsk_frontpage_elements'),
            null,
            $filemanageroptions
        );
        $mform->addHelpButton('attachment_filemanager', 'element_attachment', 'local_zsk_frontpage_elements');
        $mform->hideIf('attachment_filemanager', 'displaymode', 'neq', \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE);
        $mform->hideIf('attachment_filemanager', 'filesource', 'neq', \local_zsk_frontpage_elements\frontpage::FILESOURCE_UPLOAD);

        $mform->addElement(
            'text',
            'externallink',
            get_string('element_externallink', 'local_zsk_frontpage_elements'),
            ['size' => 80]
        );
        $mform->setType('externallink', PARAM_URL);
        $mform->addHelpButton('externallink', 'element_externallink', 'local_zsk_frontpage_elements');
        $mform->hideIf('externallink', 'displaymode', 'neq', \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE);
        $mform->hideIf('externallink', 'filesource', 'neq', \local_zsk_frontpage_elements\frontpage::FILESOURCE_EXTERNAL);

        $mform->addElement(
            'select',
            'linkicon',
            get_string('element_linkicon', 'local_zsk_frontpage_elements'),
            local_zsk_frontpage_elements_get_link_icon_options()
        );
        $mform->setType('linkicon', PARAM_ALPHANUMEXT);
        $mform->setDefault('linkicon', 'page');
        $mform->addHelpButton('linkicon', 'element_linkicon', 'local_zsk_frontpage_elements');
        $mform->hideIf('linkicon', 'displaymode', 'eq', \local_zsk_frontpage_elements\frontpage::DISPLAY_INLINE);

        $this->add_action_buttons();
    }

    /**
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation($data, $files) {
        global $USER;

        $errors = parent::validation($data, $files);
        $displaymode = (int) ($data['displaymode'] ?? \local_zsk_frontpage_elements\frontpage::DISPLAY_INLINE);

        if ($displaymode === \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE) {
            $filesource = local_zsk_frontpage_elements_normalize_filesource((int) ($data['filesource'] ?? 0));
            if ($filesource === \local_zsk_frontpage_elements\frontpage::FILESOURCE_EXTERNAL) {
                $externallink = trim((string) ($data['externallink'] ?? ''));
                if ($externallink === '' || local_zsk_frontpage_elements_normalize_external_link($externallink) === '') {
                    $errors['externallink'] = get_string('required');
                }
            } else {
                $hasfile = false;
                $draftitemid = (int) ($data['attachment_filemanager'] ?? 0);
                if ($draftitemid > 0) {
                    $usercontext = \context_user::instance($USER->id);
                    $fs = get_file_storage();
                    $draftfiles = $fs->get_area_files($usercontext->id, 'user', 'draft', $draftitemid, 'id', false);
                    $hasfile = !empty($draftfiles);
                }
                if (!$hasfile && !empty($data['id'])) {
                    $hasfile = local_zsk_frontpage_elements_get_element_attachment_file((int) $data['id']) !== null;
                }
                if (!$hasfile) {
                    $errors['attachment_filemanager'] = get_string('required');
                }
            }
        } else {
            $text = '';
            if (isset($data['content_editor']) && is_array($data['content_editor'])) {
                $text = (string) ($data['content_editor']['text'] ?? '');
            }

            if (html_is_blank($text)) {
                $errors['content_editor'] = get_string('required');
            }
        }

        return $errors;
    }
}
