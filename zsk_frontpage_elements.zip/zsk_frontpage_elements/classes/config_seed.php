<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Seeds config defaults for this plugin (avoids admin/upgradesettings redirect loops).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_zsk_frontpage_elements;

defined('MOODLE_INTERNAL') || die();

/**
 * Seed defaults via get_config/set_config only (no direct config_plugins queries).
 */
class config_seed {

    /**
     * Defaults for this plugin only.
     *
     * @return array<string, string>
     */
    public static function get_static_defaults(): array {
        return [
            'enabled' => '1',
        ];
    }

    /**
     * @return array{written: string[], skipped: int}
     */
    public static function apply_static_defaults(): array {
        $written = [];
        $skipped = 0;
        $plugin = 'local_zsk_frontpage_elements';

        if (get_config($plugin, 'version') === false) {
            return ['written' => $written, 'skipped' => $skipped];
        }

        foreach (self::get_static_defaults() as $name => $value) {
            if (get_config($plugin, $name) !== false) {
                $skipped++;
                continue;
            }
            set_config($name, $value, $plugin);
            $written[] = $plugin . '/' . $name;
        }

        return ['written' => $written, 'skipped' => $skipped];
    }

    /**
     * Write defaults for uninitialized admin settings of this plugin.
     *
     * @return array{written: string[], errors: string[]}
     */
    public static function apply_admin_defaults(): array {
        global $CFG;

        require_once($CFG->libdir . '/adminlib.php');

        $written = [];
        $errors = [];
        $plugin = 'local_zsk_frontpage_elements';

        if (get_config($plugin, 'version') === false) {
            return ['written' => $written, 'errors' => $errors];
        }

        admin_get_root(true, true);
        $uninitialized = admin_find_new_settings($plugin);
        if (empty($uninitialized)) {
            return ['written' => $written, 'errors' => $errors];
        }

        foreach ($uninitialized as $setting) {
            if (!($setting instanceof \admin_setting) || !empty($setting->nosave)) {
                continue;
            }

            $default = $setting->get_defaultsetting();
            if ($default === null) {
                $default = '';
            }
            if (is_array($default)) {
                $default = implode(',', $default);
            }

            $error = $setting->write_setting((string) $default);
            if ($error === '' || $error === true) {
                $written[] = $plugin . '/' . $setting->name;
            } else {
                $errors[] = $plugin . '/' . $setting->name . ': ' . $error;
            }
        }

        return ['written' => $written, 'errors' => $errors];
    }

    /**
     * @return array{written: string[], admin_written: string[], errors: string[], pending: string[]}
     */
    public static function apply_all(): array {
        $static = self::apply_static_defaults();
        $admin = self::apply_admin_defaults();

        return [
            'written' => $static['written'],
            'admin_written' => $admin['written'],
            'errors' => $admin['errors'],
            'pending' => self::get_pending_settings(),
        ];
    }

    /**
     * @return string[]
     */
    public static function get_pending_settings(): array {
        global $CFG;

        require_once($CFG->libdir . '/adminlib.php');

        $plugin = 'local_zsk_frontpage_elements';
        if (get_config($plugin, 'version') === false) {
            return [];
        }

        admin_get_root(true, true);

        $pending = [];
        foreach (admin_find_new_settings($plugin) as $setting) {
            $pending[] = $setting->plugin . '/' . $setting->name . ' (' . get_class($setting) . ')';
        }

        return $pending;
    }
}
