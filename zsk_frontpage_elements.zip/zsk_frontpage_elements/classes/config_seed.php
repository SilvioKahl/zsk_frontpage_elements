<?php
// This file is part of Moodle - http://moodle.org/

namespace local_zsk_frontpage_elements;

defined('MOODLE_INTERNAL') || die();

/**
 * Seeds config_plugins defaults for ZSK plugins (avoids admin/upgradesettings redirect loops).
 */
class config_seed {

    /**
     * @return array<string, array<string, string>>
     */
    public static function get_static_defaults(): array {
        $defaults = [
            'local_zsk_frontpage_elements' => [
                'enabled' => '1',
            ],
            'local_zsk_ai_generated' => [
                'enabled' => '1',
                'badgelabel' => '',
                'badgepartial' => '1',
                'license_server_url' => '',
                'license_grace_days' => '7',
                'license_key' => '',
                'meta_ampel_enabled' => '1',
                'meta_tool_enabled' => '1',
                'meta_reviewer_enabled' => '1',
                'meta_disclaimer_enabled' => '1',
                'learner_notice' => '',
                'meta_course_activity_display' => 'no_view',
            ],
            'local_zsk_p2p' => [
                'license_server_url' => '',
                'license_grace_days' => '7',
                'license_key' => '',
                'enable_course_overrides' => '1',
                'default_peers_required' => '3',
                'default_min_reviews' => '3',
                'default_threshold_percent' => '80',
                'default_anon_peers' => '1',
                'default_anon_teachers' => '0',
                'default_rereview_on_edit' => '1',
                'email_assignment_enabled' => '1',
            ],
            'local_zsk_local_tiles' => [
                'license_server_url' => '',
                'license_grace_days' => '7',
                'license_key' => '',
                'tiles_dashboard' => '1',
                'tiles_mycourses' => '1',
                'tiles_frontpage' => '0',
                'tiles_category' => '1',
                'tiles_showunenrolled' => '0',
                'tiles_category_maxdepth' => '2',
                'tiles_grid_columns' => '2',
                'tiles_image_height' => '175',
                'tiles_desc_lines' => '7',
                'footer_color_complete_bg' => '',
                'footer_color_complete_fg' => '',
                'footer_color_progress_bg' => '',
                'footer_color_progress_fg' => '',
                'footer_color_notstarted_bg' => '',
                'footer_color_notstarted_fg' => '',
                'footer_color_disabled_bg' => '',
                'footer_color_disabled_fg' => '',
                'footer_color_notenrolled_bg' => '',
                'footer_color_notenrolled_fg' => '',
                'footer_color_categorycount_bg' => '',
                'footer_color_categorycount_fg' => '',
            ],
            'local_zsk_termine' => [
                'license_server_url' => '',
                'license_grace_days' => '7',
                'license_key' => '',
                'block_dashboard' => '0',
                'block_frontpage' => '0',
                'block_preview_count' => '3',
                'block_position' => 'before',
                'accessmode' => '0',
                'email_delivery_enabled' => '1',
                'notify_enabled' => '1',
                'notify_batchsize' => '50',
                'reminder_days_before' => '1',
                'webhook_url' => '',
                'webhook_secret' => '',
            ],
            'local_zsk_local_newsletter' => [
                'email_delivery_enabled' => '1',
                'shownavigation' => '1',
                'accessmode_nav' => '0',
                'accessmode_send' => '0',
                'digest_enabled' => '0',
                'digest_day' => '1',
                'digest_hour' => '8',
                'digest_subject' => 'Neue Inhalte auf {sitename}',
                'digest_footerid' => '0',
                'digest_include' => '',
                'digest_exclude' => '',
            ],
            'local_zsk_local_statistics' => [
                'shownavigation' => '1',
                'accessmode' => '0',
                'report_notstarted_showidentity' => '0',
            ],
        ];

        if (file_exists($GLOBALS['CFG']->dirroot . '/local/zsk_local_statistics/lib.php')) {
            require_once($GLOBALS['CFG']->dirroot . '/local/zsk_local_statistics/lib.php');
            foreach (local_zsk_local_statistics_get_report_registry() as $reportdef) {
                $defaults['local_zsk_local_statistics'][$reportdef['configkey']] = '1';
            }
        }

        return $defaults;
    }

    /**
     * @return array{written: string[], skipped: int}
     */
    public static function apply_static_defaults(): array {
        $written = [];
        $skipped = 0;

        foreach (self::get_static_defaults() as $plugin => $settings) {
            if (get_config($plugin, 'version') === false) {
                continue;
            }
            foreach ($settings as $name => $value) {
                if (get_config($plugin, $name) !== false) {
                    $skipped++;
                    continue;
                }
                set_config($name, $value, $plugin);
                $written[] = $plugin . '/' . $name;
            }
        }

        return ['written' => $written, 'skipped' => $skipped];
    }

    /**
     * @return array{written: string[], errors: string[]}
     */
    public static function apply_admin_defaults(): array {
        global $DB, $CFG;

        require_once($CFG->libdir . '/adminlib.php');

        $written = [];
        $errors = [];

        admin_get_root(true, true);

        $plugins = $DB->get_records_select(
            'config_plugins',
            "plugin LIKE 'local_zsk_%' AND name = 'version'",
            null,
            'plugin ASC',
            'DISTINCT plugin'
        );

        foreach ($plugins as $record) {
            $plugin = $record->plugin;
            $uninitialized = admin_find_new_settings($plugin);
            if (empty($uninitialized)) {
                continue;
            }

            foreach ($uninitialized as $setting) {
                if (!($setting instanceof \admin_setting) || !empty($setting->nosave)) {
                    continue;
                }

                $default = $setting->get_defaultsetting();
                if ($default === null) {
                    $default = '';
                }
                if (is_array($default)) {
                    $default = implode(',', $default);
                }

                $error = $setting->write_setting((string) $default);
                if ($error === '' || $error === true) {
                    $written[] = $plugin . '/' . $setting->name;
                } else {
                    $errors[] = $plugin . '/' . $setting->name . ': ' . $error;
                }
            }
        }

        return ['written' => $written, 'errors' => $errors];
    }

    /**
     * @return array{written: string[], admin_written: string[], errors: string[], pending: string[]}
     */
    public static function apply_all(): array {
        $static = self::apply_static_defaults();
        $admin = self::apply_admin_defaults();
        $pending = self::get_pending_settings();

        return [
            'written' => $static['written'],
            'admin_written' => $admin['written'],
            'errors' => $admin['errors'],
            'pending' => $pending,
        ];
    }

    /**
     * @return string[]
     */
    public static function get_pending_settings(): array {
        global $DB, $CFG;

        require_once($CFG->libdir . '/adminlib.php');

        admin_get_root(true, true);

        $pending = [];
        $plugins = $DB->get_records_select(
            'config_plugins',
            "plugin LIKE 'local_zsk_%' AND name = 'version'",
            null,
            'plugin ASC',
            'DISTINCT plugin'
        );

        foreach ($plugins as $record) {
            $uninitialized = admin_find_new_settings($record->plugin);
            foreach ($uninitialized as $setting) {
                $pending[] = $setting->plugin . '/' . $setting->name . ' (' . get_class($setting) . ')';
            }
        }

        return $pending;
    }
}
