# ZSK eigene Startseiten-Elemente – Produktbeschreibung für Moodle-Betreiber

**ZSK eigene Startseiten-Elemente** (`local_zsk_frontpage_elements`) erweitert die **Moodle-Startseite** um beliebig viele, zentral gepflegte Inhaltsbereiche – Texte, Medien, Infoseiten und Dateilinks – und bindet sie **frei sortierbar** in die mittlere Spalte ein, neben Kursliste, Kurs-Kacheln, Terminen und anderen Startseiten-Elementen.

| | |
|---|---|
| **Plugin** | `local_zsk_frontpage_elements` |
| **Moodle** | 4.1 oder neuer (4.4+ empfohlen) |
| **Abhängigkeiten** | Keine weiteren Plugins erforderlich |
| **Optionale Integration** | `local_zsk_local_tiles`, `local_zsk_termine` (gemeinsame Startseiten-Auswahl) |
| **Sprachen** | Deutsch und Englisch (Oberfläche und Dokumentation) |

---

## Welche Probleme löst das Plugin?

Moodle bietet auf der Startseite zwar feste Bausteine (Kursliste, Ankündigungsforum, Kurs-Suche …), aber **keine flexible, mehrfach nutzbare Lösung** für institutionsweite Informationen. Betreiber stoßen deshalb häufig auf dieselben Hürden:

### Die Standard-Startseite ist zu starr

Willkommenstexte, Semesterhinweise, Hausordnungen oder Hilfe-Links lassen sich nicht komfortabel als **eigene, benannte Bereiche** unterbringen und neben anderen Inhalten sortieren.

### Infos landen in Kursen, im Theme oder in HTML-Blöcken

Ohne zentrale Lösung pflegen Admins oft Dummy-Kurse, Theme-Anpassungen oder manuelle HTML in Blöcken – **wartungsintensiv**, uneinheitlich und für Lehrende verwirrend („Warum steht das nicht im Kurs?“).

### Lange Texte überladen die Startseite

Ausführliche Inhalte auf der ersten Seite machen die Startseite unübersichtlich. Nutzer scrollen an wichtigen Kurzinfos vorbei.

### PDFs und Dokumente sind schwer mit einem Klick erreichbar

Formulare, Ordnungen oder Leitfäden sollen **direkt** geöffnet werden, ohne Umweg über Kurs, Datei-Aktivität oder externe Verlinkung im Theme.

### Unterschiedliche Zielgruppen (Gast vs. eingeloggt)

Gäste und eingeloggte Nutzer brauchen oft **unterschiedliche** Informationen auf der Startseite – ohne zwei getrennte Moodle-Instanzen.

### Zusammenspiel mit anderen Startseiten-Features

Kurs-Kacheln, Termine und eigene Texte sollen in **einer definierten Reihenfolge** in der Mitte erscheinen, nicht übereinander oder an falscher Stelle.

### Zu viele Rechte für zu wenige Aufgaben

Startseiten-Inhalte sollen von der **Zentraladministration** gepflegt werden, nicht von jeder Lehrperson im Kurs. Standard-Moodle bietet dafür keinen dedizierten, einfachen Workflow.

---

## Vorteile des Plugins

### Direkt in Moodle integriert

Anlegen, Bearbeiten und Einordnen erfolgen in der **gewohnten Moodle-Administration**. Kein Theme-Hack, kein separater CMS und keine Kursaktivitäten nötig.

### Drei Anzeigemodi pro Element

| Modus | Nutzen |
|-------|--------|
| **Direkt auf der Startseite** | Titel und Inhalt sofort sichtbar (HTML, Bilder) |
| **Als Link (eigene Seite)** | Nur Titel auf der Startseite → voller Text auf eigener Seite |
| **Als Datei-Link** | PDF/Dokument öffnet sich direkt (Upload oder externe URL) |

### Freie Positionierung

Elemente erscheinen in den **Startseiten-Einstellungen** von Moodle (`frontpageloggedin` / `frontpage`) als „ZSK: [Titel]“ und lassen sich gegenüber Kursliste, Kacheln, Terminen usw. **sortieren**.

### Zentrale Pflege, klare Zuständigkeit

Nur Nutzer mit `local/zsk_frontpage_elements:manage` (standardmäßig *Manager*) bearbeiten Inhalte. Lehrende und Studierende **lesen** – sie pflegen nicht.

### Medien und Dateien

HTML-Editor mit eingebetteten Bildern; Datei-Upload für PDFs; optional externe URLs. Link-Symbole (Seite, Datei, Kalender, Info …) für erkennbare Navigation.

### Gäste und eingeloggte Nutzer

Getrennte Einbindung in **Startseite vor Anmeldung** und **Startseite nach Anmeldung**.

### ZSK-Ökosystem

Das Plugin erweitert die Startseiten-Dropdown-Auswahl und arbeitet mit **ZSK Kachelansicht** und **ZSK Termine** in einer gemeinsamen Layout-Logik zusammen – ohne diese Plugins vorauszusetzen.

### Betriebssicherheit

- Plugin global ein-/ausschaltbar
- Beim Löschen eines Elements wird der zugehörige Layout-Slot bereinigt
- Privacy API: speichert Admin-Inhalte, **keine** personenbezogenen Besucherdaten

---

## Funktionsübersicht im Überblick

| Bereich | Was Sie erhalten |
|---------|------------------|
| **Verwaltung** | Liste aller Elemente, Anlegen, Bearbeiten, Löschen |
| **Inhalt** | Titel, HTML-Inhalt, Datei-Anhang, externe Link-URL |
| **Anzeige** | Inline, Link-Seite, Datei-Link |
| **Startseite** | Einbindung in Moodle-Startseiten-Layout, Mitte-Spalte |
| **Einstellungen** | Plugin aktivieren/deaktivieren |
| **Berechtigung** | Capability `manage` für Manager |
| **Öffentlichkeit** | Startseiten-Inhalte für alle Besucher sichtbar (inkl. Gäste) |

---

## Für wen ist das Plugin geeignet?

- **Hochschulen und Bildungsträger**, die Semesterinfos und Orientierungshilfen auf der Startseite bündeln
- **Unternehmen und Schulungsanbieter**, die Willkommenstexte und Richtlinien zentral ausspielen
- **Moodle-Partner**, die Kunden eine wartbare Startseiten-Lösung ohne Theme-Programmierung anbieten möchten

---

## Abgrenzung

Das Plugin ist **kein** Kurs-Plugin, **kein** Ersatz für das Ankündigungsforum und **kein** Page-Builder fürs gesamte Theme. Mehrsprachige Inhalte werden so gepflegt, wie der Administrator sie eingibt (ggf. separates Element pro Sprache).

---

## Technische Voraussetzungen (kurz)

- Moodle **4.1+**
- Schreibrechte auf `moodle/local/`
- Keine Lizenzpflicht (GPL, kein Freemium)

Ausführliche Einrichtung: [INSTALLATION_ADMIN.md](INSTALLATION_ADMIN.md) · Einstellungen: siehe gleichnamige Admin-Seite in Moodle.

---

*Silvio Kuhn – die-schulungsexperten.de · Stand: Plugin 1.4.4*
