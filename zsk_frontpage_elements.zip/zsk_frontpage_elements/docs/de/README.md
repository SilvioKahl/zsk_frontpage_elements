# Dokumentation (Deutsch)

Anleitungen für das Plugin **ZSK eigene Startseiten-Elemente** (`local_zsk_frontpage_elements`).

## Produkt & Überblick

| Dokument | Beschreibung |
|----------|--------------|
| [PRODUKTBESCHREIBUNG.md](PRODUKTBESCHREIBUNG.md) | Aufgaben, Funktionen, gelöste Probleme für Betreiber |

## Für Administratoren

| Dokument | Beschreibung |
|----------|--------------|
| [INSTALLATION_ADMIN.md](INSTALLATION_ADMIN.md) | Installation, Startseiten-Einbindung, Anzeigemodi, Fehlerbehebung |

## Für Lehrende und Studierende

| Dokument | Beschreibung |
|----------|--------------|
| [KLICKANLEITUNG_DOZENTEN.md](KLICKANLEITUNG_DOZENTEN.md) | Was Lehrende auf der Startseite sehen; keine eigene Pflege ohne Admin-Rechte |
| [KLICKANLEITUNG_STUDENTEN.md](KLICKANLEITUNG_STUDENTEN.md) | Startseiten-Inhalte finden und nutzen (Text, Links, Dateien) |

## Technische Hilfen

| Datei | Beschreibung |
|-------|--------------|
| [../recover_via_database.sql](../recover_via_database.sql) | SQL-Notfall: fehlende `config_plugins`-Einträge (Redirect-Schleife) |

## Englische Versionen

→ [../en/README.md](../en/README.md)
