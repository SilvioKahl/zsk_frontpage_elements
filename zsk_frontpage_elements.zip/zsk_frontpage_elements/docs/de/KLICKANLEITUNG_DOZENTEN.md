# Klickanleitung für Dozenten

**Plugin:** ZSK eigene Startseiten-Elemente (`local_zsk_frontpage_elements`)  
**Ziel:** Verstehen, was Sie auf der Moodle-Startseite sehen – und wer Inhalte pflegt.

**Weitere Dokumentation:** [Installationsanleitung](INSTALLATION_ADMIN.md) · [Studenten-Anleitung](KLICKANLEITUNG_STUDENTEN.md)

---

## Kurzüberblick

Die **Moodle-Startseite** (Site home) kann vom Systembetreuer um **zusätzliche Informationsbereiche** ergänzt werden – z. B. Hinweise zur Organisation, Links zu PDFs oder ausführliche Texte.

Diese Bereiche werden **nicht im Kurs** gepflegt, sondern zentral durch die **Website-Administration**. Als Dozent/in sehen Sie die Inhalte wie alle anderen Nutzer; Sie bearbeiten sie in der Regel **nicht** selbst.

---

## Was Sie auf der Startseite sehen können

Je nach Konfiguration Ihrer Institution erscheinen eines oder mehrere der folgenden Muster:

### Direkt sichtbarer Textblock

- Eine **Überschrift** und darunter **Text, Bilder oder Medien**
- Beispiel: Willkommenstext, Semesterhinweise, Kontaktinformationen

### Link zu einer Infoseite

- Nur ein **klickbarer Titel** mit kleinem Symbol (z. B. Seite, Kalender, Datei)
- Nach dem Klick: eigene Seite mit dem vollständigen Inhalt
- Oben: Link **„Zurück zur Startseite“**

### Link zu einer Datei

- Klickbarer Titel öffnet eine **Datei direkt** (häufig PDF)
- Externe Links öffnen sich in einem neuen Browser-Tab

Die Elemente stehen in der **mittleren Spalte** der Startseite, oft neben Kursliste, Kurs-Kacheln oder „Nächste Termine“ – je nachdem, was Ihre Administration aktiviert hat.

---

## Was Dozenten normalerweise nicht tun

| Aufgabe | Wer ist zuständig? |
|---------|-------------------|
| Texte auf der Startseite ändern | Website-Administrator/in |
| PDF-Link auf der Startseite austauschen | Website-Administrator/in |
| Reihenfolge der Startseiten-Blöcke | Website-Administrator/in |
| Kursinhalte pflegen | Dozent/in (im jeweiligen Kurs) |

Wenn ein Startseiten-Hinweis falsch oder veraltet ist, wenden Sie sich an den **Moodle-Support** bzw. die zuständige Administration – nicht an den Kurseditor.

---

## Ausnahme: Erweiterte Berechtigung

In seltenen Fällen kann die Administration die Berechtigung **Startseiten-Elemente verwalten** (`local/zsk_frontpage_elements:manage`) an einzelne Rollen vergeben. Nur dann sehen Sie unter **Website-Administration → ZSK eigene Startseiten-Elemente** die Pflegemasken. Standardmäßig gilt das **nicht** für die Rolle *Lehrer/in*.

---

## Abgrenzung zu Kurs und Dashboard

| Ort | Inhalt |
|-----|--------|
| **Startseite** (`/`) | Institutionsweite Infos, Kursübersicht, ggf. Termine |
| **Dashboard** (`/my/`) | Persönliche Übersicht nach Anmeldung |
| **Kurs** | Lehrmaterial, Aktivitäten, Forum usw. |

Startseiten-Elemente betreffen **nicht** einzelne Kurse. Kurstermine auf der Kursseite kommen ggf. vom Plugin **ZSK Termine zu diesem Kurs** – das ist ein separates Modul.

---

## Häufige Fragen

**Ich finde keinen Menüpunkt zum Bearbeiten der Startseiten-Texte.**  
Das ist normal. Die Pflege liegt bei der Administration.

**Ein Link auf der Startseite funktioniert nicht.**  
Melden Sie das dem Support; mögliche Ursachen: fehlende Datei, falsche URL, Element nicht mehr aktiv.

**Kann ich denselben Text auch im Kurs anzeigen?**  
Nein – kopieren Sie den Inhalt bei Bedarf in eine Kursaktivität (Seite, Buch, Datei) oder bitten Sie die Administration um einen passenden Startseiten-Eintrag.
