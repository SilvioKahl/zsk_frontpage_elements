# Installationsanleitung für Administratoren

**Plugin:** `local_zsk_frontpage_elements` (ZSK eigene Startseiten-Elemente)  
**Zielgruppe:** Systemadministratoren und Moodle-Manager  
**Stand:** Plugin-Version 1.4.4

---

## Was das Plugin leistet

Mit diesem Plugin legen Sie **eigene Inhaltsbereiche für die Moodle-Startseite** an und ordnen sie frei in der Mitte der Startseite ein – zusammen mit Kursliste, Kurs-Kacheln, Terminen und anderen Moodle-Elementen.

Typische Inhalte:

- Willkommenstexte und Hinweise (direkt sichtbar)
- Verlinkte Infoseiten (Titel auf der Startseite → Inhalt auf eigener Seite)
- PDF- und Dokumenten-Links (Datei öffnet sich direkt beim Klick)

**Pflege:** ausschließlich über die Website-Administration (Rolle *Manager*). Lehrende und Studierende **lesen** die Inhalte; sie bearbeiten sie nicht im Kurs.

---

## Systemvoraussetzungen

| Anforderung | Version |
|-------------|---------|
| Moodle | 4.1 oder höher (empfohlen: 4.4+) |
| PHP | wie von Ihrer Moodle-Version gefordert |
| Datenbank | MySQL, MariaDB, PostgreSQL oder SQL Server |
| Schreibrechte | auf `moodle/local/` |

### Optionale ZSK-Erweiterungen (gleiche Startseiten-Auswahl)

Wenn zusätzlich installiert, erscheinen in den **Startseiten-Einstellungen** weitere Einträge:

| Plugin | Eintrag in der Auswahl |
|--------|------------------------|
| `local_zsk_local_tiles` | Kurs-Kacheln |
| `local_zsk_termine` | Nächste Termine |

Diese Plugins sind **nicht** Voraussetzung für die Startseiten-Elemente.

---

## Schritt 1: Plugin-Dateien bereitstellen

### ZIP-Struktur (wichtig)

Nach dem Entpacken muss der Pfad so aussehen:

```text
moodle/local/zsk_frontpage_elements/version.php
```

Das ZIP enthält den Ordner `zsk_frontpage_elements/`, **nicht** die Plugin-Dateien direkt im Archiv-Root.

### Installation

1. Ordner `zsk_frontpage_elements` nach `moodle/local/zsk_frontpage_elements/` kopieren (FTP, Git oder ZIP-Upload).
2. Als Administrator anmelden.
3. **Website-Administration → Benachrichtigungen** öffnen und das Upgrade durchführen.

---

## Schritt 2: Plugin aktivieren

**Website-Administration → ZSK eigene Startseiten-Elemente → Einstellungen**

| Einstellung | Empfehlung |
|-------------|------------|
| **Plugin aktivieren** | Ja |

Wenn deaktiviert, werden keine eigenen Elemente angezeigt und sie erscheinen nicht in den Startseiten-Einstellungen.

---

## Schritt 3: Startseiten-Elemente anlegen

**Website-Administration → ZSK eigene Startseiten-Elemente → Startseiten-Elemente verwalten**

1. **Element hinzufügen** klicken.
2. **Titel** vergeben (wird auf der Startseite bzw. als Linktext angezeigt).
3. **Anzeige auf der Startseite** wählen (siehe unten).
4. Inhalt bzw. Datei eintragen.
5. **Speichern**.

Auf der Übersichtsseite sehen Sie pro Element die **Slot-ID** (z. B. `10001`). Diese ID wird intern für die Reihenfolge in den Startseiten-Einstellungen verwendet.

### Anzeigemodi

| Modus | Verhalten auf der Startseite |
|-------|------------------------------|
| **Direkt auf der Startseite** | Titel als Überschrift, HTML-Inhalt darunter (Bilder und Medien im Editor möglich) |
| **Als Link (eigene Seite)** | Nur ein klickbarer Titel mit Symbol; Inhalt auf `/local/zsk_frontpage_elements/view.php` |
| **Als Datei-Link** | Klickbarer Titel öffnet eine Datei – hochgeladen in Moodle oder per externer URL (z. B. PDF) |

Bei Link- und Datei-Modus können Sie ein **Link-Symbol** wählen (Seite, Datei, Kalender, …).

---

## Schritt 4: Elemente auf der Startseite einordnen

**Website-Administration → Startseite → Startseite-Einstellungen**

Relevant sind zwei Listen:

| Moodle-Einstellung | Gilt für |
|--------------------|----------|
| **Startseite nach Anmeldung** (`frontpageloggedin`) | Eingeloggte Nutzer |
| **Startseite vor Anmeldung** (`frontpage`) | Gäste (optional) |

In der Mehrfachauswahl erscheinen Ihre Elemente als **„ZSK: [Titel]“**. Zusätzlich können Kursliste, Kurs-Suche, Kurs-Kacheln, Nächste Termine usw. gewählt werden.

**Reihenfolge:** Die Reihenfolge in der Liste bestimmt die Anordnung in der **mittleren Spalte** der Startseite (unterhalb des Kopfbereichs). Die Kurs-Suche (falls aktiv) bleibt an ihrer Moodle-Standardposition; die ZSK-Elemente werden per Skript korrekt einsortiert.

**Tipp:** Nach Änderungen die Startseite im Browser neu laden (ggf. Cache leeren).

---

## Schritt 5: Berechtigungen

| Fähigkeit | Standard | Bedeutung |
|-----------|----------|-----------|
| `local/zsk_frontpage_elements:manage` | Nur *Manager* | Elemente anlegen, bearbeiten, löschen |

Lehrende (*Editing teacher*) haben diese Berechtigung **nicht**. Wenn einzelne Lehrende Inhalte pflegen sollen, müssen Sie die Fähigkeit gezielt in einer Rolle vergeben (Systemkontext). In der Regel bleibt die Pflege bei der Zentraladministration.

Startseiten-Inhalte sind für **alle Besucher** sichtbar (auch Gäste), sobald das Element in der passenden Startseiten-Liste steht.

---

## Fehlerbehebung

### Element erscheint nicht auf der Startseite

1. Plugin aktiviert? (**Einstellungen → Plugin aktivieren**)
2. Element in **Startseite nach Anmeldung** (oder **vor Anmeldung**) ausgewählt?
3. Bei Modus **Datei-Link:** Datei hochgeladen bzw. gültige externe URL?
4. Bei Modus **Link/Direkt:** Inhalt im Editor nicht leer?
5. Browser-Cache und Moodle-Caches leeren.

### „ZSK: …“ fehlt in der Startseiten-Auswahl

- Plugin-Upgrade erneut ausführen.
- Prüfen, ob mindestens ein Element unter **Startseiten-Elemente verwalten** existiert.
- Prüfen, ob ein anderes ZSK-Plugin die Startseiten-Einstellungen überschreibt (sollte mit aktuellen Versionen von `local_zsk_local_tiles` abgestimmt sein).

### Redirect-Schleife (`ERR_TOO_MANY_REDIRECTS` auf `admin/upgradesettings.php`)

Tritt auf, wenn in `mdl_config_plugins` Einträge für ZSK-Plugins fehlen.

**Variante A – CLI (empfohlen):**

```bash
php local/zsk_frontpage_elements/cli/seed_defaults.php
```

**Variante B – Browser (ohne SSH):**

1. `recover_config.php` aus dem Plugin-Ordner hochladen.
2. `RECOVERY_TOKEN` in der Datei auf einen Zufallswert setzen.
3. Im Browser aufrufen: `https://ihre-moodle.site/local/zsk_frontpage_elements/recover_config.php?token=…`
4. Datei danach **vom Server löschen**.

**Variante C – Datenbank:**

Siehe [recover_via_database.sql](../recover_via_database.sql) (Tabellenpräfix anpassen).

Anschließend Browser-Cookies für die Site löschen und die Startseite neu laden.

### Element gelöscht, aber Slot bleibt in der Konfiguration

Beim Löschen entfernt das Plugin den Slot automatisch aus `frontpage` und `frontpageloggedin`. Falls ein Eintrag hängen bleibt, in den Startseiten-Einstellungen manuell entfernen.

---

## Checkliste nach der Installation

- [ ] Upgrade ohne Fehler abgeschlossen
- [ ] **Plugin aktivieren** = Ja
- [ ] Mindestens ein Test-Element angelegt
- [ ] Element in **Startseite nach Anmeldung** ausgewählt und positioniert
- [ ] Startseite als eingeloggter Nutzer geprüft (Inline, Link, Datei)
- [ ] Optional: gleiche Prüfung für Gäste (**Startseite vor Anmeldung**)

---

## Weitere Dokumentation

- [Klickanleitung Dozenten](KLICKANLEITUNG_DOZENTEN.md)
- [Klickanleitung Studenten](KLICKANLEITUNG_STUDENTEN.md)
- [Englische Version](../en/INSTALLATION_ADMIN.md)

*Stand: ZSK eigene Startseiten-Elemente 1.4.4*
