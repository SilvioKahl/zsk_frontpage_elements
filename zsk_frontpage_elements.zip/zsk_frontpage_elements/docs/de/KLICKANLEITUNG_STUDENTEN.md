# Klickanleitung für Studierende

**Plugin:** ZSK eigene Startseiten-Elemente (`local_zsk_frontpage_elements`)  
**Ziel:** Zusatzinformationen auf der Moodle-Startseite finden und nutzen.

**Weitere Dokumentation:** [Dozenten-Anleitung](KLICKANLEITUNG_DOZENTEN.md)

---

## Wo Sie die Inhalte finden

Nach dem Öffnen der **Moodle-Startseite** (oft die erste Seite nach dem Login oder unter **Startseite** im Menü) sehen Sie in der **mittleren Spalte** zusätzliche Bereiche – neben der Kursliste oder Kurs-Kacheln.

Das sind **institutionsweite Hinweise** Ihrer Hochschule oder Organisation, nicht Inhalte aus einem einzelnen Kurs.

---

## Drei Darstellungsarten

### 1. Text direkt auf der Startseite

- Sie sehen eine **Überschrift** und darunter den **Text** (ggf. mit Bildern).
- Einfach lesen und scrollen – kein Klick nötig.
- Beispiele: Willkommen, Semesterinfos, Hinweise zur Nutzung von Moodle.

### 2. Link zu einer Infoseite

- Es erscheint nur eine Zeile mit **Symbol + Titel** (blauer Link).
- **Klicken** Sie auf den Titel.
- Sie gelangen auf eine eigene Seite mit dem vollständigen Text.
- Oben: **„Zurück zur Startseite“** – damit kommen Sie zurück.

### 3. Link zu einer Datei (z. B. PDF)

- Ebenfalls **Symbol + Titel** als Link.
- **Klick** öffnet die Datei (PDF, Dokument …) im Browser oder lädt sie herunter.
- Manche Links öffnen sich in einem **neuen Tab** (externe Adressen).

---

## Was Sie nicht tun müssen

- Sie müssen Startseiten-Inhalte **nicht bearbeiten** oder ausfüllen.
- Es gibt **keine Abgabe** und **keine Bewertung** für diese Bereiche.
- Für Kursarbeit nutzen Sie die **Kursseite** – nicht die Startseite.

---

## Wenn etwas nicht funktioniert

| Problem | Was tun? |
|---------|----------|
| Link führt ins Leere | Support / Moodle-Hilfe der Institution melden |
| PDF öffnet sich nicht | Anderen Browser probieren; Pop-up-Blocker prüfen |
| Text veraltet (falsches Semester o. Ä.) | Dozent/in oder Support informieren – nur die Administration kann Startseiten-Texte ändern |
| Bereich fehlt komplett | Nicht jede Institution nutzt alle Elemente; Kursinfos stehen weiterhin in Ihren Kursen |

---

## Startseite vs. Dashboard vs. Kurs

| Ort | Zweck |
|-----|--------|
| **Startseite** | Infos für alle, Kursübersicht |
| **Dashboard** (`Meine Startseite` / `/my/`) | Ihre persönliche Übersicht |
| **Kurs** | Unterrichtsmaterial, Aufgaben, Forum |

Die hier beschriebenen Zusatzblöcke betreffen nur die **Startseite**.
