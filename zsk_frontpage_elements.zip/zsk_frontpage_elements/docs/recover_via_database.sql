-- ZSK Moodle: Redirect-Schleife beheben (phpMyAdmin / Datenbank)
-- Tabellenpräfix anpassen (hier: mdl_)
-- INSERT IGNORE = vorhandene Werte bleiben unverändert

-- Termine (local_zsk_termine) – Version 1.4.5
INSERT IGNORE INTO mdl_config_plugins (plugin, name, value) VALUES
('local_zsk_termine', 'license_server_url', ''),
('local_zsk_termine', 'license_grace_days', '7'),
('local_zsk_termine', 'license_key', ''),
('local_zsk_termine', 'block_dashboard', '0'),
('local_zsk_termine', 'block_frontpage', '0'),
('local_zsk_termine', 'block_preview_count', '3'),
('local_zsk_termine', 'block_position', 'before'),
('local_zsk_termine', 'accessmode', '0'),
('local_zsk_termine', 'email_delivery_enabled', '1'),
('local_zsk_termine', 'notify_enabled', '1'),
('local_zsk_termine', 'notify_batchsize', '50'),
('local_zsk_termine', 'reminder_days_before', '1'),
('local_zsk_termine', 'webhook_url', ''),
('local_zsk_termine', 'webhook_secret', '');

-- Newsletter (local_zsk_local_newsletter) – Version 1.0.5
INSERT IGNORE INTO mdl_config_plugins (plugin, name, value) VALUES
('local_zsk_local_newsletter', 'email_delivery_enabled', '1'),
('local_zsk_local_newsletter', 'shownavigation', '1'),
('local_zsk_local_newsletter', 'accessmode_nav', '0'),
('local_zsk_local_newsletter', 'accessmode_send', '0'),
('local_zsk_local_newsletter', 'digest_enabled', '0'),
('local_zsk_local_newsletter', 'digest_day', '1'),
('local_zsk_local_newsletter', 'digest_hour', '8'),
('local_zsk_local_newsletter', 'digest_subject', 'Neue Inhalte auf {sitename}'),
('local_zsk_local_newsletter', 'digest_footerid', '0'),
('local_zsk_local_newsletter', 'digest_include', ''),
('local_zsk_local_newsletter', 'digest_exclude', '');

-- Statistik (falls noch offen)
INSERT IGNORE INTO mdl_config_plugins (plugin, name, value) VALUES
('local_zsk_local_statistics', 'shownavigation', '1'),
('local_zsk_local_statistics', 'accessmode', '0'),
('local_zsk_local_statistics', 'report_notstarted_showidentity', '0'),
('local_zsk_local_statistics', 'report_enable_users', '1'),
('local_zsk_local_statistics', 'report_enable_enrollments', '1'),
('local_zsk_local_statistics', 'report_enable_enrollments_anonymous', '1'),
('local_zsk_local_statistics', 'report_enable_course_incomplete', '1'),
('local_zsk_local_statistics', 'report_enable_course_notstarted', '1'),
('local_zsk_local_statistics', 'report_enable_newusers', '1'),
('local_zsk_local_statistics', 'report_enable_newusers_filtered', '1'),
('local_zsk_local_statistics', 'report_enable_users_cumulative', '1'),
('local_zsk_local_statistics', 'report_enable_logins_hourly', '1'),
('local_zsk_local_statistics', 'report_enable_logins_blocks', '1'),
('local_zsk_local_statistics', 'report_enable_logins_monthly', '1'),
('local_zsk_local_statistics', 'report_enable_logins_peaks', '1'),
('local_zsk_local_statistics', 'report_enable_logins_patterns', '1'),
('local_zsk_local_statistics', 'report_enable_newcourses', '1'),
('local_zsk_local_statistics', 'report_enable_courses_cumulative', '1');

-- Lizenz-Felder weiterer ZSK-Plugins
INSERT IGNORE INTO mdl_config_plugins (plugin, name, value) VALUES
('local_zsk_local_tiles', 'license_key', ''),
('local_zsk_ai_generated', 'license_key', ''),
('local_zsk_p2p', 'license_key', '');
