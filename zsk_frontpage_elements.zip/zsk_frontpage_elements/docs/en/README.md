# Documentation (English)

Guides for the plugin **ZSK custom site home elements** (`local_zsk_frontpage_elements`).

## Product overview

| Document | Description |
|----------|-------------|
| [PRODUCT_DESCRIPTION.md](PRODUCT_DESCRIPTION.md) | Tasks, features, problems solved for operators |

## For administrators

| Document | Description |
|----------|-------------|
| [INSTALLATION_ADMIN.md](INSTALLATION_ADMIN.md) | Installation, site home layout, display modes, troubleshooting |

## For teachers and students

| Document | Description |
|----------|-------------|
| [TEACHER_GUIDE.md](TEACHER_GUIDE.md) | What teachers see on the site home; no editing without admin rights |
| [STUDENT_GUIDE.md](STUDENT_GUIDE.md) | Finding and using site home content (text, links, files) |

## Technical helpers

| File | Description |
|------|-------------|
| [../recover_via_database.sql](../recover_via_database.sql) | SQL emergency fix for missing `config_plugins` rows (redirect loop) |

## German versions

→ [../de/README.md](../de/README.md)
