# ZSK custom site home elements – product description for Moodle operators

**ZSK custom site home elements** (`local_zsk_frontpage_elements`) extends the **Moodle site home** with any number of centrally maintained content blocks — text, media, info pages, and file links — and places them **in freely chosen order** in the centre column, alongside the course list, course tiles, events, and other site home items.

| | |
|---|---|
| **Plugin** | `local_zsk_frontpage_elements` |
| **Moodle** | 4.1 or later (4.4+ recommended) |
| **Dependencies** | No other plugins required |
| **Optional integration** | `local_zsk_local_tiles`, `local_zsk_termine` (shared site home picker) |
| **Languages** | German and English (UI and documentation) |

---

## What problems does the plugin solve?

Moodle’s site home offers fixed building blocks (course list, announcements forum, course search …) but **no flexible, reusable way** to present institution-wide information. Operators often face the same issues:

### The default site home is too rigid

Welcome messages, semester notes, policies, or help links cannot easily be added as **named, repeatable sections** and sorted relative to other content.

### Content ends up in courses, the theme, or HTML blocks

Without a central solution, admins maintain dummy courses, theme tweaks, or manual HTML in blocks — **high maintenance**, inconsistent, and confusing for teachers (“Why isn’t this in my course?”).

### Long text clutters the site home

Full articles on the landing page make the site home hard to scan; users scroll past important short notices.

### PDFs and documents are hard to open in one click

Forms, policies, or guides should open **directly**, without a detour through a course, file activity, or theme link.

### Different audiences (guest vs. logged in)

Guests and logged-in users often need **different** information on the site home — without running two Moodle instances.

### Working with other site home features

Course tiles, events, and custom text should appear in a **defined order** in the centre column, not stacked incorrectly.

### Too many permissions for too small a task

Site home content should be maintained by **central administration**, not by every teacher in a course. Standard Moodle does not offer a dedicated, simple workflow for this.

---

## Benefits

### Integrated in Moodle

Create, edit, and position content in **familiar site administration**. No theme hacks, no separate CMS, no course activities required.

### Three display modes per element

| Mode | Benefit |
|------|---------|
| **Inline on site home** | Title and content visible immediately (HTML, images) |
| **As link (dedicated page)** | Title only on site home → full text on its own page |
| **As file link** | PDF/document opens directly (upload or external URL) |

### Free positioning

Elements appear in Moodle **front page settings** (`frontpageloggedin` / `frontpage`) as “ZSK: [title]” and can be **ordered** relative to course list, tiles, events, etc.

### Central maintenance, clear ownership

Only users with `local/zsk_frontpage_elements:manage` (by default *Manager*) edit content. Teachers and students **read** — they do not maintain site home blocks.

### Media and files

HTML editor with embedded images; file upload for PDFs; optional external URLs. Link icons (page, file, calendar, info …) for clear navigation.

### Guests and logged-in users

Separate placement in **front page items when logged out** and **when logged in**.

### ZSK ecosystem

Extends the site home picker and works with **ZSK course tiles** and **ZSK events** in a shared layout model — without requiring those plugins.

### Operational safety

- Global enable/disable switch
- Deleting an element cleans up its layout slot
- Privacy API: stores admin content, **no** personal visitor tracking data

---

## Feature overview

| Area | What you get |
|------|----------------|
| **Management** | List, create, edit, delete elements |
| **Content** | Title, HTML, file attachment, external URL |
| **Display** | Inline, link page, file link |
| **Site home** | Integration in Moodle front page layout, centre column |
| **Settings** | Enable/disable plugin |
| **Permission** | `manage` capability for managers |
| **Visibility** | Site home content visible to all visitors (including guests) |

---

## Who is it for?

- **Universities and training providers** bundling semester info and orientation on the site home
- **Companies and L&D teams** publishing welcome text and policies centrally
- **Moodle partners** offering maintainable site home content without theme development

---

## What it is not

Not a **course** plugin, not a replacement for the **announcements forum**, and not a full **theme page builder**. Multilingual content is entered as the administrator provides it (separate element per language if needed).

---

## Technical requirements (brief)

- Moodle **4.1+**
- Write access to `moodle/local/`
- No license required (GPL, no freemium)

Setup: [INSTALLATION_ADMIN.md](INSTALLATION_ADMIN.md).

---

*Silvio Kuhn – die-schulungsexperten.de · Version: plugin 1.4.4*
