# Installation guide for administrators

**Plugin:** `local_zsk_frontpage_elements` (ZSK custom site home elements)  
**Audience:** System administrators and Moodle managers  
**Version:** Plugin release 1.4.4

---

## What this plugin does

This plugin lets you create **custom content blocks for the Moodle site home** and place them freely in the centre column — alongside the course list, course tiles, events, and other Moodle items.

Typical content:

- Welcome messages and notices (shown inline)
- Linked info pages (title on the site home → full content on a dedicated page)
- PDF and document links (file opens directly when clicked)

**Maintenance:** via site administration only (*Manager* role). Teachers and students **view** the content; they do not edit it inside a course.

---

## System requirements

| Requirement | Version |
|-------------|---------|
| Moodle | 4.1 or higher (recommended: 4.4+) |
| PHP | As required by your Moodle version |
| Database | MySQL, MariaDB, PostgreSQL, or SQL Server |
| Write access | to `moodle/local/` |

### Optional ZSK add-ons (same site home picker)

If installed, these add extra choices in **Front page settings**:

| Plugin | Picker label |
|--------|----------------|
| `local_zsk_local_tiles` | Course tiles |
| `local_zsk_termine` | Upcoming events |

These plugins are **not** required for custom site home elements.

---

## Step 1: Deploy plugin files

### ZIP structure (important)

After unpacking, the path must look like this:

```text
moodle/local/zsk_frontpage_elements/version.php
```

The ZIP must contain the folder `zsk_frontpage_elements/`, **not** plugin files at the archive root.

### Installation

1. Copy the folder `zsk_frontpage_elements` to `moodle/local/zsk_frontpage_elements/` (FTP, Git, or ZIP upload).
2. Log in as administrator.
3. Open **Site administration → Notifications** and run the upgrade.

---

## Step 2: Enable the plugin

**Site administration → ZSK custom site home elements → Settings**

| Setting | Recommendation |
|---------|----------------|
| **Enable plugin** | Yes |

When disabled, custom elements are not shown and do not appear in front page settings.

---

## Step 3: Create site home elements

**Site administration → ZSK custom site home elements → Manage site home elements**

1. Click **Add element**.
2. Enter a **Title** (shown on the site home or as link text).
3. Choose **Display on site home** (see below).
4. Add content or a file.
5. Click **Save changes**.

The overview lists each element’s **Slot ID** (e.g. `10001`). This ID is used internally for ordering in front page settings.

### Display modes

| Mode | Behaviour on the site home |
|------|------------------------------|
| **Inline on site home** | Heading plus HTML content below (images and media in the editor supported) |
| **As link (dedicated page)** | Clickable title with icon only; content on `/local/zsk_frontpage_elements/view.php` |
| **As file link** | Clickable title opens a file — uploaded in Moodle or via external URL (e.g. PDF) |

For link and file modes you can pick a **link icon** (page, file, calendar, etc.).

---

## Step 4: Place elements on the site home

**Site administration → Front page → Front page settings**

Two lists matter:

| Moodle setting | Applies to |
|----------------|------------|
| **Front page items when logged in** (`frontpageloggedin`) | Logged-in users |
| **Front page items when logged out** (`frontpage`) | Guests (optional) |

Your elements appear as **“ZSK: [title]”**. You can also select course list, course search, course tiles, upcoming events, etc.

**Order:** The list order defines placement in the **centre column** of the site home. Course search (if enabled) keeps its Moodle default position; ZSK elements are positioned by a small client script.

**Tip:** Reload the site home after changes (clear browser cache if needed).

---

## Step 5: Permissions

| Capability | Default | Meaning |
|------------|---------|---------|
| `local/zsk_frontpage_elements:manage` | *Manager* only | Create, edit, delete elements |

Teachers (*Editing teacher*) do **not** have this capability by default. If specific staff should maintain content, grant the capability in the system context. Usually maintenance stays with central admins.

Site home content is visible to **all visitors** (including guests) once the element is in the appropriate front page list.

---

## Troubleshooting

### Element does not appear on the site home

1. Plugin enabled? (**Settings → Enable plugin**)
2. Element selected in **Front page items when logged in** (or **when logged out**)?
3. **File link** mode: file uploaded or valid external URL?
4. **Link / inline** mode: editor content not empty?
5. Clear browser and Moodle caches.

### “ZSK: …” missing from the front page picker

- Run the plugin upgrade again.
- Check that at least one element exists under **Manage site home elements**.
- Check whether another ZSK plugin overrides front page settings (should be aligned with current `local_zsk_local_tiles` versions).

### Redirect loop (`ERR_TOO_MANY_REDIRECTS` on `admin/upgradesettings.php`)

Occurs when `mdl_config_plugins` rows for ZSK plugins are missing.

**Option A – CLI (recommended):**

```bash
php local/zsk_frontpage_elements/cli/seed_defaults.php
```

**Option B – Browser (no SSH):**

1. Upload `recover_config.php` from the plugin folder.
2. Set `RECOVERY_TOKEN` in the file to a random value.
3. Open in browser: `https://your-moodle.site/local/zsk_frontpage_elements/recover_config.php?token=…`
4. **Delete** the file from the server afterwards.

**Option C – Database:**

See [recover_via_database.sql](../recover_via_database.sql) (adjust table prefix).

Then clear browser cookies for the site and reload the site home.

### Element deleted but slot remains in config

Deleting an element removes its slot from `frontpage` and `frontpageloggedin` automatically. If an entry remains, remove it manually in front page settings.

---

## Post-installation checklist

- [ ] Upgrade completed without errors
- [ ] **Enable plugin** = Yes
- [ ] At least one test element created
- [ ] Element selected and positioned in **Front page items when logged in**
- [ ] Site home checked while logged in (inline, link, file modes)
- [ ] Optional: same check for guests (**Front page items when logged out**)

---

## Further documentation

- [Teacher guide](TEACHER_GUIDE.md)
- [Student guide](STUDENT_GUIDE.md)
- [German version](../de/INSTALLATION_ADMIN.md)

*Version: ZSK custom site home elements 1.4.4*
