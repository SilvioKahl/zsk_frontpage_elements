# Guide for students

**Plugin:** ZSK custom site home elements (`local_zsk_frontpage_elements`)  
**Purpose:** Find and use extra information on the Moodle site home.

**More documentation:** [Teacher guide](TEACHER_GUIDE.md)

---

## Where to find the content

When you open the **Moodle site home** (often the first page after login, or via **Home** in the menu), look in the **centre column** for additional sections — next to the course list or course tiles.

This is **institution-wide information** from your university or organisation, not material from a single course.

---

## Three display types

### 1. Text directly on the site home

- You see a **heading** and **text** below (sometimes with images).
- Just read and scroll — no click required.
- Examples: welcome message, semester info, Moodle usage tips.

### 2. Link to an info page

- One line with **icon + title** (blue link).
- **Click** the title.
- You reach a dedicated page with the full text.
- At the top: **“Back to site home”**.

### 3. Link to a file (e.g. PDF)

- Again **icon + title** as a link.
- **Click** opens the file (PDF, document …) in the browser or downloads it.
- Some links open in a **new tab** (external addresses).

---

## What you do not need to do

- You do **not** edit or submit site home content.
- There is **no assignment** and **no grading** for these blocks.
- For coursework, use your **course page** — not the site home.

---

## If something does not work

| Problem | What to do |
|---------|------------|
| Link goes nowhere | Report to support / your institution’s Moodle help |
| PDF does not open | Try another browser; check pop-up blockers |
| Text is outdated (wrong semester, etc.) | Tell your teacher or support — only administrators can change site home text |
| Block is missing entirely | Not every institution uses all elements; course info is still in your courses |

---

## Site home vs. dashboard vs. course

| Location | Purpose |
|----------|---------|
| **Site home** | Info for everyone, course overview |
| **Dashboard** (`My home` / `/my/`) | Your personal overview |
| **Course** | Learning materials, assignments, forums |

The blocks described here apply only to the **site home**.
