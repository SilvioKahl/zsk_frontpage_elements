# Guide for teachers

**Plugin:** ZSK custom site home elements (`local_zsk_frontpage_elements`)  
**Purpose:** Understand what you see on the Moodle site home — and who maintains that content.

**More documentation:** [Installation guide](INSTALLATION_ADMIN.md) · [Student guide](STUDENT_GUIDE.md)

---

## Quick overview

The **Moodle site home** can include **extra information blocks** added by your institution — e.g. organisational notices, PDF links, or longer texts.

These blocks are **not** maintained inside a course. They are managed centrally in **site administration**. As a teacher, you view them like any other user; you usually **do not** edit them yourself.

---

## What you may see on the site home

Depending on your institution’s setup, you may see one or more of the following patterns:

### Inline text block

- A **heading** with **text, images, or media** below
- Examples: welcome message, semester information, contact details

### Link to an info page

- A **clickable title** with a small icon (page, calendar, file, etc.)
- After clicking: a dedicated page with the full content
- At the top: **“Back to site home”**

### Link to a file

- Clickable title opens a **file directly** (often a PDF)
- External links may open in a new browser tab

Elements appear in the **centre column** of the site home, often next to the course list, course tiles, or “Upcoming events” — depending on what your admins enabled.

---

## What teachers normally do not do

| Task | Who is responsible? |
|------|---------------------|
| Change site home text | Site administrator |
| Replace a PDF link on the site home | Site administrator |
| Reorder site home blocks | Site administrator |
| Maintain course content | Teacher (in each course) |

If site home information is wrong or outdated, contact **Moodle support** or your central administration — not the course editor.

---

## Exception: extended permission

In rare cases, administrators may grant **Manage site home elements** (`local/zsk_frontpage_elements:manage`) to specific roles. Only then will you see maintenance screens under **Site administration → ZSK custom site home elements**. By default, the *Teacher* role does **not** have this.

---

## Site home vs. dashboard vs. course

| Location | Content |
|----------|---------|
| **Site home** (`/`) | Institution-wide info, course overview, maybe events |
| **Dashboard** (`/my/`) | Personal overview after login |
| **Course** | Teaching materials, activities, forums, etc. |

Site home elements do **not** apply to individual courses. Course events on the course page may come from the separate **ZSK course events** activity — that is a different module.

---

## FAQ

**I cannot find a menu item to edit site home text.**  
That is normal. Maintenance is handled by administrators.

**A link on the site home does not work.**  
Report it to support; possible causes: missing file, invalid URL, inactive element.

**Can I show the same text in my course?**  
No — copy the content into a course activity (Page, Book, File) if needed, or ask administration for a suitable site home entry.
