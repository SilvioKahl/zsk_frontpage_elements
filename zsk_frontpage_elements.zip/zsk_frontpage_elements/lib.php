<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Source file for local_zsk_frontpage_elements (lib.php).
 *
 * @package    local_zsk_frontpage_elements
 * @copyright  2025 Silvio Kuhn
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

/**
 * Ensure config_plugins defaults exist (avoids upgradesettings loops without CLI seed).
 *
 * @return int Number of values written.
 */
function local_zsk_frontpage_elements_seed_config_defaults(): int {
    $defaults = [
        'enabled' => '1',
    ];

    $written = 0;
    foreach ($defaults as $name => $value) {
        if (get_config('local_zsk_frontpage_elements', $name) === false) {
            set_config($name, $value, 'local_zsk_frontpage_elements');
            $written++;
        }
    }

    return $written;
}

/**
 * @param int $displaymode
 * @return int
 */
function local_zsk_frontpage_elements_normalize_displaymode(int $displaymode): int {
    if ($displaymode === \local_zsk_frontpage_elements\frontpage::DISPLAY_LINK) {
        return \local_zsk_frontpage_elements\frontpage::DISPLAY_LINK;
    }
    if ($displaymode === \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE) {
        return \local_zsk_frontpage_elements\frontpage::DISPLAY_FILE;
    }

    return \local_zsk_frontpage_elements\frontpage::DISPLAY_INLINE;
}

/**
 * @param \stdClass $element
 * @return string
 */
function local_zsk_frontpage_elements_get_display_mode_label(\stdClass $element): string {
    if (\local_zsk_frontpage_elements\frontpage::is_file_display($element)) {
        return get_string('displaymode_file', 'local_zsk_frontpage_elements');
    }
    if (\local_zsk_frontpage_elements\frontpage::is_link_display($element)) {
        return get_string('displaymode_link', 'local_zsk_frontpage_elements');
    }

    return get_string('displaymode_inline', 'local_zsk_frontpage_elements');
}

/**
 * @return array<string, array{component: string, pix: string}>
 */
function local_zsk_frontpage_elements_get_link_icon_definitions(): array {
    return [
        'page' => ['component' => 'mod_page', 'pix' => 'monologo'],
        'file' => ['component' => 'mod_resource', 'pix' => 'monologo'],
        'book' => ['component' => 'mod_book', 'pix' => 'monologo'],
        'info' => ['component' => 'core', 'pix' => 'i/info'],
        'news' => ['component' => 'core', 'pix' => 'i/news'],
        'help' => ['component' => 'core', 'pix' => 'i/help'],
        'globe' => ['component' => 'core', 'pix' => 'i/globe'],
        'group' => ['component' => 'core', 'pix' => 'i/group'],
        'calendar' => ['component' => 'core', 'pix' => 'i/calendar'],
        'comment' => ['component' => 'core', 'pix' => 'i/comment'],
    ];
}

/**
 * @return array<string, string>
 */
function local_zsk_frontpage_elements_get_link_icon_options(): array {
    $options = [];
    foreach (array_keys(local_zsk_frontpage_elements_get_link_icon_definitions()) as $key) {
        $options[$key] = get_string('linkicon_' . $key, 'local_zsk_frontpage_elements');
    }

    return $options;
}

/**
 * @param string $linkicon
 * @return string
 */
function local_zsk_frontpage_elements_normalize_linkicon(string $linkicon): string {
    $definitions = local_zsk_frontpage_elements_get_link_icon_definitions();
    if (isset($definitions[$linkicon])) {
        return $linkicon;
    }

    return 'page';
}

/**
 * @param \stdClass $element
 * @return string
 */
function local_zsk_frontpage_elements_render_link_icon(\stdClass $element): string {
    global $OUTPUT;

    $key = local_zsk_frontpage_elements_normalize_linkicon((string) ($element->linkicon ?? 'page'));
    $definition = local_zsk_frontpage_elements_get_link_icon_definitions()[$key];

    return $OUTPUT->image_icon(
        $definition['pix'],
        get_string('linkicon_' . $key, 'local_zsk_frontpage_elements'),
        $definition['component'],
        ['class' => 'local-zsk-fp-element-icon activityicon']
    );
}

/**
 * Editor options for element content (embedded files/images).
 *
 * @return array
 */
function local_zsk_frontpage_elements_get_editor_options(): array {
    global $CFG;

    require_once($CFG->libdir . '/formslib.php');

    return [
        'maxfiles' => EDITOR_UNLIMITED_FILES,
        'maxbytes' => $CFG->maxbytes,
        'trusttext' => false,
        'subdirs' => true,
        'context' => context_system::instance(),
        'noclean' => true,
    ];
}

/**
 * File manager options for the direct file link display mode.
 *
 * @return array
 */
function local_zsk_frontpage_elements_get_filemanager_options(): array {
    global $CFG;

    return [
        'subdirs' => 0,
        'maxfiles' => 1,
        'maxbytes' => $CFG->maxbytes,
        'accepted_types' => '*',
        'context' => context_system::instance(),
    ];
}

/**
 * @param int $elementid
 * @return \stored_file|null
 */
function local_zsk_frontpage_elements_get_element_attachment_file(int $elementid): ?\stored_file {
    if ($elementid <= 0) {
        return null;
    }

    $context = context_system::instance();
    $fs = get_file_storage();
    $files = $fs->get_area_files(
        $context->id,
        'local_zsk_frontpage_elements',
        'attachment',
        $elementid,
        'itemid, filepath, filename',
        false
    );

    foreach ($files as $file) {
        if (!$file->is_directory()) {
            return $file;
        }
    }

    return null;
}

/**
 * @param int $elementid
 * @return \moodle_url|null
 */
function local_zsk_frontpage_elements_get_element_attachment_url(int $elementid): ?\moodle_url {
    $file = local_zsk_frontpage_elements_get_element_attachment_file($elementid);
    if ($file === null) {
        return null;
    }

    return \moodle_url::make_pluginfile_url(
        $file->get_contextid(),
        $file->get_component(),
        $file->get_filearea(),
        $file->get_itemid(),
        $file->get_filepath(),
        $file->get_filename(),
        false
    );
}

/**
 * @param int $filesource
 * @return int
 */
function local_zsk_frontpage_elements_normalize_filesource(int $filesource): int {
    if ($filesource === \local_zsk_frontpage_elements\frontpage::FILESOURCE_EXTERNAL) {
        return \local_zsk_frontpage_elements\frontpage::FILESOURCE_EXTERNAL;
    }

    return \local_zsk_frontpage_elements\frontpage::FILESOURCE_UPLOAD;
}

/**
 * @param string $url
 * @return string
 */
function local_zsk_frontpage_elements_normalize_external_link(string $url): string {
    $url = trim($url);
    if ($url === '') {
        return '';
    }

    if (!preg_match('#^https?://#i', $url)) {
        return '';
    }

    $cleaned = clean_param($url, PARAM_URL);
    return is_string($cleaned) ? $cleaned : '';
}

/**
 * @param \stdClass $element
 * @return array{url: \moodle_url, external: bool}|null
 */
function local_zsk_frontpage_elements_get_element_file_link_target(\stdClass $element): ?array {
    if (!\local_zsk_frontpage_elements\frontpage::is_file_display($element)) {
        return null;
    }

    $filesource = local_zsk_frontpage_elements_normalize_filesource((int) ($element->filesource ?? 0));
    if ($filesource === \local_zsk_frontpage_elements\frontpage::FILESOURCE_EXTERNAL) {
        $externallink = local_zsk_frontpage_elements_normalize_external_link((string) ($element->externallink ?? ''));
        if ($externallink === '') {
            return null;
        }

        return [
            'url' => new \moodle_url($externallink),
            'external' => true,
        ];
    }

    $url = local_zsk_frontpage_elements_get_element_attachment_url((int) $element->id);
    if ($url === null) {
        return null;
    }

    return [
        'url' => $url,
        'external' => false,
    ];
}

/**
 * @param \stdClass $data
 * @param int $elementid
 * @param \context $context
 * @param array $filemanageroptions
 * @return void
 */
function local_zsk_frontpage_elements_store_attachment_file(
    \stdClass $data,
    int $elementid,
    \context $context,
    array $filemanageroptions
): void {
    require_once($GLOBALS['CFG']->libdir . '/filelib.php');

    file_postupdate_standard_filemanager(
        $data,
        'attachment',
        $filemanageroptions,
        $context,
        'local_zsk_frontpage_elements',
        'attachment',
        $elementid
    );
}

/**
 * Persist editor content and move embedded files from draft to the element file area.
 *
 * @param \stdClass $data Form data including the editor array in {@see $data} content.
 * @param int $elementid
 * @param \context $context
 * @param array $editoroptions
 * @return array{text: string, format: int}
 */
function local_zsk_frontpage_elements_store_editor_content(
    \stdClass $data,
    int $elementid,
    \context $context,
    array $editoroptions
): array {
    require_once($GLOBALS['CFG']->libdir . '/filelib.php');

    $text = '';
    $format = FORMAT_HTML;
    $draftitemid = 0;

    if (isset($data->content_editor) && is_array($data->content_editor)) {
        $text = $data->content_editor['text'] ?? '';
        $format = (int) ($data->content_editor['format'] ?? FORMAT_HTML);
        $draftitemid = (int) ($data->content_editor['itemid'] ?? 0);
    } else if (isset($data->content) && is_array($data->content)) {
        $text = $data->content['text'] ?? '';
        $format = (int) ($data->content['format'] ?? FORMAT_HTML);
        $draftitemid = (int) ($data->content['itemid'] ?? 0);
    } else if (isset($data->content)) {
        $text = (string) $data->content;
        $format = (int) ($data->contentformat ?? FORMAT_HTML);
    }

    if ($draftitemid > 0 && (int) ($editoroptions['maxfiles'] ?? 0) !== 0) {
        $text = file_save_draft_area_files(
            $draftitemid,
            $context->id,
            'local_zsk_frontpage_elements',
            'content',
            $elementid,
            $editoroptions,
            $text
        );
    }

    return [
        'text' => $text,
        'format' => $format,
    ];
}

/**
 * Format element HTML for output, resolving embedded plugin files.
 *
 * @param \stdClass $element
 * @return string
 */
function local_zsk_frontpage_elements_format_element_content(\stdClass $element): string {
    global $CFG;

    require_once($CFG->libdir . '/filelib.php');

    $context = context_system::instance();
    $content = (string) ($element->content ?? '');

    if ($content !== '') {
        $content = file_rewrite_pluginfile_urls(
            $content,
            'pluginfile.php',
            $context->id,
            'local_zsk_frontpage_elements',
            'content',
            (int) $element->id
        );
    }

    return format_text(
        $content,
        (int) ($element->contentformat ?? FORMAT_HTML),
        [
            'context' => $context,
            'overflowdiv' => true,
            'noclean' => true,
        ]
    );
}

/**
 * Delete stored files for an element.
 *
 * @param int $elementid
 * @return void
 */
function local_zsk_frontpage_elements_delete_element_files(int $elementid): void {
    if ($elementid <= 0) {
        return;
    }

    $context = context_system::instance();
    $fs = get_file_storage();
    $fs->delete_area_files($context->id, 'local_zsk_frontpage_elements', 'content', $elementid);
    $fs->delete_area_files($context->id, 'local_zsk_frontpage_elements', 'attachment', $elementid);
}

/**
 * @return bool
 */
function local_zsk_frontpage_elements_is_enabled(): bool {
    $value = get_config('local_zsk_frontpage_elements', 'enabled');
    if ($value === false || $value === null || $value === '') {
        return true;
    }

    return ((string) $value === '1');
}

/**
 * @return void
 */
function local_zsk_frontpage_elements_require_manage(): void {
    require_capability('local/zsk_frontpage_elements:manage', context_system::instance());
}

/**
 * @param int $id
 * @return stdClass|null
 */
function local_zsk_frontpage_elements_get_element(int $id): ?stdClass {
    global $DB;

    if ($id <= 0) {
        return null;
    }

    $record = $DB->get_record('local_zsk_frontpage_elements', ['id' => $id]);
    return $record ?: null;
}

/**
 * @return stdClass[]
 */
function local_zsk_frontpage_elements_get_all_elements(): array {
    global $DB;

    return $DB->get_records('local_zsk_frontpage_elements', null, 'name ASC');
}

/**
 * Register front page element stylesheet in <head> or return a late <link> fallback.
 *
 * @return string Optional <link> tag when <head> was already printed.
 */
function local_zsk_frontpage_elements_require_styles(): string {
    global $PAGE;

    static $handled = false;
    if ($handled || empty($PAGE)) {
        return '';
    }

    $csspath = '/local/zsk_frontpage_elements/styles.css';

    if (!$PAGE->requires->is_head_done()) {
        $handled = true;
        return '';
    }

    $handled = true;
    $url = (new moodle_url($csspath))->out(false);

    return html_writer::empty_tag('link', [
        'rel' => 'stylesheet',
        'href' => $url,
        'data-local-zsk-fp-elements' => '1',
    ]);
}

/**
 * Whether front page element styles should load on the current page.
 *
 * @return bool
 */
function local_zsk_frontpage_elements_page_needs_styles(): bool {
    global $PAGE;

    if (empty($PAGE) || $PAGE->pagetype !== 'site-index' || !local_zsk_frontpage_elements_is_enabled()) {
        return false;
    }

    return \local_zsk_frontpage_elements\frontpage::layout_needs_coordinator(isloggedin() && !isguestuser());
}

/**
 * Register plugin stylesheet via Moodle core callback.
 *
 * @param context $context
 * @return string[]
 */
function local_zsk_frontpage_elements_get_stylesheets_for_context(context $context): array {
    if (!local_zsk_frontpage_elements_page_needs_styles()) {
        return [];
    }

    return ['/local/zsk_frontpage_elements/styles.css'];
}

/**
 * Remove a deleted element from front page layout config.
 *
 * @param int $elementid
 * @return void
 */
function local_zsk_frontpage_elements_remove_slot_from_config(int $elementid): void {
    global $CFG;

    $slot = \local_zsk_frontpage_elements\frontpage::slot_for_element($elementid);

    foreach (['frontpage', 'frontpageloggedin'] as $key) {
        $layout = isset($CFG->$key) ? (string) $CFG->$key : '';
        if ($layout === '') {
            continue;
        }

        $slots = [];
        foreach (explode(',', $layout) as $value) {
            $value = trim($value);
            if ($value === '' || $value === 'none' || $value === $slot) {
                continue;
            }
            $slots[] = $value;
        }

        set_config($key, implode(',', $slots));
    }
}

/**
 * Serves embedded files from element content.
 *
 * @param stdClass $course
 * @param stdClass $cm
 * @param context $context
 * @param string $filearea
 * @param array $args
 * @param bool $forcedownload
 * @param array $options
 * @return bool
 */
function local_zsk_frontpage_elements_pluginfile(
    $course,
    $cm,
    $context,
    $filearea,
    $args,
    $forcedownload,
    array $options = []
) {
    if ($context->contextlevel !== CONTEXT_SYSTEM) {
        return false;
    }

    if ($filearea !== 'content' && $filearea !== 'attachment') {
        return false;
    }

    $itemid = (int) array_shift($args);
    if ($itemid <= 0) {
        return false;
    }

    $filename = array_pop($args);
    $filepath = $args ? '/' . implode('/', $args) . '/' : '/';

    $fs = get_file_storage();
    $file = $fs->get_file(
        $context->id,
        'local_zsk_frontpage_elements',
        $filearea,
        $itemid,
        $filepath,
        $filename
    );
    if (!$file || $file->is_directory()) {
        return false;
    }

    // Public front page content – visible to all visitors.
    send_stored_file($file, null, 0, $forcedownload, $options);
}
